﻿// <copyright file="App.xaml.cs" company="Ayvan">
// Copyright (c) 2019 All Rights Reserved
// </copyright>
// <author>UTKARSHLAPTOP\Utkarsh</author>
// <date>2019-08-18</date>

namespace DataMigrator
{
	using System.Windows;
	using Ayvan.WPF.MaterialThemes;
	using Unity;

	/// <summary>
	/// Interaction logic for App.xaml
	/// </summary>
	public partial class App : Application
	{
		/// <summary>
		/// Initializes a new instance of the <see cref="App"/> class.
		/// </summary>
		public App()
		{
			UnityConfig.Initialize();
		}

		/// <summary>
		/// The OnStartup
		/// </summary>
		/// <param name="e">The e<see cref="StartupEventArgs"/></param>
		protected override void OnStartup(StartupEventArgs e)
		{
			base.OnStartup(e);
			ThemeManger.ApplyTheme();
		}
	}
}
