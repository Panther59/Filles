﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using Ayvan.WPF.MaterialThemes;
using DataMigrator.Common;
using DataMigrator.Contracts;
using DataMigrator.Controls;
using DataMigrator.ViewModels;
using Unity;

namespace DataMigrator
{
	public static class UnityConfig
	{
		public static IUnityContainer Container { get; set; }
		private static IUnityContainer GetContainer()
		{
			var container = new UnityContainer();
			return container;
		}

		public static void Initialize()
		{
			Container = GetContainer();
			RegisterTypes(Container);
		}

		private static void RegisterTypes(IUnityContainer container)
		{
			container.RegisterSingleton<IResolver, Resolver>();
			container.RegisterSingleton<IAppDataHelper, AppDataHelper>();
			container.RegisterSingleton<IItemContainerResolver, ItemContainerResolver>();
			container.RegisterType<ISqlServerHelper, SqlServerHelper>();

			container.RegisterSingleton<MainWindow>();
			container.RegisterSingleton<ThemeWindow>();

			container.RegisterType<IItemContainer, ItemContainer>();
			container.RegisterSingleton<UserControl, ApplicationsView>(Screens.Applications.ToString());
			container.RegisterSingleton<UserControl, DatabasesView>(Screens.Databases.ToString());
			container.RegisterSingleton<UserControl, HomeView>(Screens.Home.ToString());
			container.RegisterSingleton<UserControl, MainView>(Screens.Main.ToString());
			container.RegisterSingleton<UserControl, TablesView>(Screens.Tables.ToString());
			container.RegisterSingleton<UserControl, SettingsView>(Screens.Settings.ToString());

			container.RegisterSingleton<BaseViewModel, MainViewModel>(Screens.Main.ToString());
			container.RegisterSingleton<BaseViewModel, ApplicationsViewModel>(Screens.Applications.ToString());
			container.RegisterSingleton<BaseViewModel, DatabasesViewModel>(Screens.Databases.ToString());
			container.RegisterSingleton<BaseViewModel, HomeViewModel>(Screens.Home.ToString());
			container.RegisterSingleton<BaseViewModel, TablesViewModel>(Screens.Tables.ToString());
			container.RegisterSingleton<BaseViewModel, SettingsViewModel>(Screens.Settings.ToString());

			container.RegisterType<TableViewModel>();
			container.RegisterType<ApplicationViewModel>();
		}
	}
}
