﻿// <copyright file="IAppDataHelper.cs" company="Ayvan">
// Copyright (c) 2019 All Rights Reserved
// </copyright>
// <author>UTKARSHLAPTOP\Utkarsh</author>
// <date>2019-08-18</date>

namespace DataMigrator.Contracts
{
	using System.Collections.Generic;
	using DataMigrator.Models;
	using DataMigrator.ViewModels;

	/// <summary>
	/// Defines the <see cref="IAppDataHelper" />
	/// </summary>
	public interface IAppDataHelper
	{
		/// <summary>
		/// Gets or sets the Applications
		/// </summary>
		List<ApplicationViewModel> Applications { get; set; }

		/// <summary>
		/// Gets or sets the AppTablesConfigurations
		/// </summary>
		List<AppTablesConfiguration> AppTablesConfigurations { get; set; }

		/// <summary>
		/// Gets or sets the Databases
		/// </summary>
		List<DatabaseViewModel> Databases { get; set; }

		/// <summary>
		/// Gets or sets the Settings
		/// </summary>
		Settings Settings { get; set; }
	}
}
