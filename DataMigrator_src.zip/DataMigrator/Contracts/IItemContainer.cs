﻿// <copyright file="IItemContainer.cs" company="Ayvan">
// Copyright (c) 2019 All Rights Reserved
// </copyright>
// <author>UTKARSHLAPTOP\Utkarsh</author>
// <date>2019-08-18</date>

namespace DataMigrator.Contracts
{
	using DataMigrator.ViewModels;

	/// <summary>
	/// Defines the <see cref="IItemContainer" />
	/// </summary>
	public interface IItemContainer
	{
		/// <summary>
		/// Gets or sets the Content
		/// </summary>
		object Content { get; set; }

		/// <summary>
		/// Gets or sets the Name
		/// </summary>
		string Name { get; set; }

		/// <summary>
		/// Gets or sets the ViewModel
		/// </summary>
		BaseViewModel ViewModel { get; set; }
	}

	/// <summary>
	/// Defines the <see cref="IItemContainerResolver" />
	/// </summary>
	public interface IItemContainerResolver
	{
		/// <summary>
		/// The GetView
		/// </summary>
		/// <param name="name">The name<see cref="string"/></param>
		/// <returns>The <see cref="IItemContainer"/></returns>
		IItemContainer GetView(string name);
	}
}
