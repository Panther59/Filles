﻿// <copyright file="ISqlServerHelper.cs" company="Ayvan">
// Copyright (c) 2019 All Rights Reserved
// </copyright>
// <author>UTKARSHLAPTOP\Utkarsh</author>
// <date>2019-08-18</date>

namespace DataMigrator.Contracts
{
	using System;
	using System.Collections.Generic;
	using System.Data;
	using DataMigrator.Models;

	/// <summary>
	/// Defines the <see cref="ISqlServerHelper" />
	/// </summary>
	public interface ISqlServerHelper
	{
		/// <summary>
		/// The BulkTransfer
		/// </summary>
		/// <param name="sourceConnectionString">The sourceConnectionString<see cref="string"/></param>
		/// <param name="targetConnectionString">The targetConnectionString<see cref="string"/></param>
		/// <param name="tableDetails">The tableDetails<see cref="Models.TableConfiguration"/></param>
		void BulkTransfer(string sourceConnectionString, string targetConnectionString, Models.TableConfiguration tableDetails);

		/// <summary>
		/// The ClearTargetData
		/// </summary>
		/// <param name="targetConnectionString">The targetConnectionString<see cref="string"/></param>
		/// <param name="tableDetails">The tableDetails<see cref="TableConfiguration"/></param>
		void ClearTargetData(string targetConnectionString, TableConfiguration tableDetails, int maxDeleteRecordCount, Action<long> batchAction);

		/// <summary>
		/// The GetAllTables
		/// </summary>
		/// <param name="connectionString">The connectionString<see cref="string"/></param>
		/// <returns>The <see cref="List{string}"/></returns>
		List<string> GetAllTables(string connectionString);

		/// <summary>
		/// The GetSourceData
		/// </summary>
		/// <param name="sourceConnectionString">The sourceConnectionString<see cref="string"/></param>
		/// <param name="tableDetails">The tableDetails<see cref="TableConfiguration"/></param>
		/// <returns>The <see cref="DataTable"/></returns>
		DataTable GetSourceData(string sourceConnectionString, TableConfiguration tableDetails);

		/// <summary>
		/// The GetTableDataCount
		/// </summary>
		/// <param name="connectionString">The connectionString<see cref="string"/></param>
		/// <param name="tableDetails">The tableDetails<see cref="TableConfiguration"/></param>
		/// <returns>The <see cref="int"/></returns>
		int GetTableDataCount(string connectionString, TableConfiguration tableDetails);

		/// <summary>
		/// The SaveToTargetTable
		/// </summary>
		/// <param name="targetConnectionString">The targetConnectionString<see cref="string"/></param>
		/// <param name="tableDetails">The tableDetails<see cref="TableConfiguration"/></param>
		/// <param name="data">The data<see cref="DataTable"/></param>
		void SaveToTargetTable(string targetConnectionString, TableConfiguration tableDetails, DataTable data);

		/// <summary>
		/// The TestConnection
		/// </summary>
		/// <param name="connectionString">The connectionString<see cref="string"/></param>
		void TestConnection(string connectionString);

		/// <summary>
		/// The TransferData
		/// </summary>
		/// <param name="sourceConnectionString">The sourceConnectionString<see cref="string"/></param>
		/// <param name="targetConnectionString">The targetConnectionString<see cref="string"/></param>
		/// <param name="tableDetails">The tableDetails<see cref="TableConfiguration"/></param>
		/// <param name="batchSize">The batchSize<see cref="int"/></param>
		/// <param name="batchAction">The batchAction<see cref="Action{long}"/></param>
		void TransferData(string sourceConnectionString, string targetConnectionString, TableConfiguration tableDetails, int batchSize, Action<long> batchAction);
	}
}
