﻿// <copyright file="AppHelper.cs" company="Ayvan">
// Copyright (c) 2019 All Rights Reserved
// </copyright>
// <author>UTKARSHLAPTOP\Utkarsh</author>
// <date>2019-08-17</date>

namespace DataMigrator.Common
{
	using System;
	using System.Collections.Generic;
	using System.IO;
	using Ayvan.ErrorLogger;
	using DataMigrator.Contracts;
	using DataMigrator.Models;
	using DataMigrator.ViewModels;
	using Newtonsoft.Json;

	/// <summary>
	/// Defines the <see cref="AppDataHelper" />
	/// </summary>
	public class AppDataHelper : IAppDataHelper
	{
		/// <summary>
		/// Defines the applicationsFilePath
		/// </summary>
		private readonly string applicationsFilePath;

		/// <summary>
		/// Defines the databases
		/// </summary>
		private readonly List<DatabaseViewModel> databases;

		/// <summary>
		/// Defines the databasesFilePath
		/// </summary>
		private readonly string databasesFilePath;

		/// <summary>
		/// Initializes a new instance of the <see cref="AppDataHelper"/> class.
		/// </summary>
		public AppDataHelper()
		{
			var appDataPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "DataMigrator");
			this.databasesFilePath = Path.Combine(appDataPath, "Databases.json");
			this.applicationsFilePath = Path.Combine(appDataPath, "Applications.json");
			this.applicationTablesFilePath = Path.Combine(appDataPath, "ApplicationTables.json");
			this.settingsFilePath = Path.Combine(appDataPath, "Settings.json");
		}

		/// <summary>
		/// Gets or sets the Applications
		/// </summary>
		public List<ApplicationViewModel> Applications
		{
			get { return this.GetData<List<ApplicationViewModel>>(this.applicationsFilePath); }
			set { this.SaveData(value, this.applicationsFilePath); }
		}

		/// <summary>
		/// Gets the applicationTablesFilePath
		/// </summary>
		public string applicationTablesFilePath { get; }

		private readonly string settingsFilePath;

		/// <summary>
		/// Gets or sets the AppTablesConfigurations
		/// </summary>
		public List<AppTablesConfiguration> AppTablesConfigurations
		{
			get { return this.GetData<List<AppTablesConfiguration>>(this.applicationTablesFilePath); }
			set { this.SaveData(value, this.applicationTablesFilePath); }
		}

		/// <summary>
		/// Gets or sets the Databases
		/// </summary>
		public List<DatabaseViewModel> Databases
		{
			get { return this.GetData<List<DatabaseViewModel>>(this.databasesFilePath); }
			set { this.SaveData(value, this.databasesFilePath); }
		}

		public Settings Settings
		{
			get
			{
				var setting = this.GetData<Settings>(this.settingsFilePath);
				if (setting == null)
				{
					setting = new Settings { MaxDeleteRecordCount = 10000, MaxInsertRecordCount = 10000 };
				}

				return setting;
			}
			set { this.SaveData(value, this.settingsFilePath); }
		}

		/// <summary>
		/// The GetDatabases
		/// </summary>
		/// <typeparam name="T"></typeparam>
		/// <param name="fileName">The fileName<see cref="string"/></param>
		/// <returns>The <see cref="List{DatabaseViewModel}"/></returns>
		private T GetData<T>(string fileName)
		{
			try
			{
				if (File.Exists(fileName))
				{
					var fileContent = File.ReadAllText(fileName);
					var list = JsonConvert.DeserializeObject<T>(fileContent);

					return list;
				}

			}
			catch (Exception ex)
			{
				ErrorLog.LogException(ex);
			}

			return default(T);
		}

		/// <summary>
		/// The SaveData
		/// </summary>
		/// <typeparam name="T"></typeparam>
		/// <param name="databases">The databases<see cref="T"/></param>
		/// <param name="fileName">The fileName<see cref="string"/></param>
		private void SaveData<T>(T databases, string fileName)
		{
			try
			{
				if (databases != null)
				{
					var content = JsonConvert.SerializeObject(databases);
					var fileInfo = new FileInfo(fileName);
					if (fileInfo.Directory.Exists == false)
					{
						Directory.CreateDirectory(fileInfo.DirectoryName);
					}

					File.WriteAllText(fileName, content);
				}
			}
			catch (Exception ex)
			{
				ErrorLog.LogException(ex);
			}
		}
	}
}
