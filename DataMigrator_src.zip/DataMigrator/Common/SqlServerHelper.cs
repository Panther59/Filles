﻿// <copyright file="SqlServerHelper.cs" company="Ayvan">
// Copyright (c) 2019 All Rights Reserved
// </copyright>
// <author>UTKARSHLAPTOP\Utkarsh</author>
// <date>2019-08-18</date>

namespace DataMigrator.Common
{
	using System;
	using System.Linq;
	using System.Collections.Generic;
	using System.Data;
	using System.Data.SqlClient;
	using Ayvan.ErrorLogger;
	using DataMigrator.Contracts;
	using DataMigrator.Models;

	/// <summary>
	/// Defines the <see cref="SqlServerHelper" />
	/// </summary>
	public class SqlServerHelper : ISqlServerHelper
	{
		/// <summary>
		/// Defines the maxDeleteRecordCount
		/// </summary>
		private readonly int maxDeleteRecordCount;

		/// <summary>
		/// Defines the deleteQueryFormat
		/// </summary>
		private string deleteQueryFormat = @"WHILE (@@ROWCOUNT > 0)
BEGIN
    DELETE TOP ({0}) FROM {1} WHERE {2}
END";

		/// <summary>
		/// Initializes a new instance of the <see cref="SqlServerHelper"/> class.
		/// </summary>
		/// <param name="appDataHelper">The appDataHelper<see cref="IAppDataHelper"/></param>
		public SqlServerHelper(IAppDataHelper appDataHelper)
		{
			this.maxDeleteRecordCount = appDataHelper.Settings.MaxDeleteRecordCount;
		}

		/// <inheritdoc />
		public void BulkTransfer(string sourceConnectionString, string targetConnectionString, Models.TableConfiguration tableDetails)
		{
			try
			{
				DataTable table = new DataTable();

				SqlConnection sourceConnection = new SqlConnection(sourceConnectionString);
				SqlConnection targetConnection = new SqlConnection(targetConnectionString);
				//I assume you know better what is your connection string

				SqlDataAdapter adapter = null;
				if (tableDetails.DefaultLoadType == LoadType.FullLoad)
				{
					adapter = new SqlDataAdapter("SELECT * FROM " + tableDetails.Name + " (NOLOCK) ", sourceConnection);
				}
				else
				{
					adapter = new SqlDataAdapter("SELECT * FROM " + tableDetails.Name + " (NOLOCK) WHERE " + tableDetails.PartialWhereQuery, sourceConnection);
				}

				adapter.Fill(table);
				sourceConnection.Close();
				sourceConnection.Dispose();

				targetConnection.Open();

				if (tableDetails.DefaultLoadType == LoadType.FullLoad)
				{
					string sqlTrunc = "TRUNCATE TABLE " + tableDetails.Name;
					SqlCommand cmd = new SqlCommand(sqlTrunc, targetConnection);
					cmd.ExecuteNonQuery();
				}
				else
				{
					string sqlQuery = string.Format(this.deleteQueryFormat, tableDetails.Name, tableDetails.PartialWhereQuery);
					SqlCommand cmd = new SqlCommand(sqlQuery, targetConnection);
					cmd.ExecuteNonQuery();
				}

				SqlBulkCopy bulkcopy = new SqlBulkCopy(targetConnection);
				bulkcopy.DestinationTableName = tableDetails.Name;
				bulkcopy.WriteToServer(table);
				targetConnection.Close();
				targetConnection.Dispose();
			}
			catch (Exception ex)
			{
				ErrorLog.LogException(ex);
			}
		}

		/// <inheritdoc />
		public void ClearTargetData(string targetConnectionString, TableConfiguration tableDetails)
		{
			SqlConnection targetConnection = new SqlConnection(targetConnectionString);
			targetConnection.Open();
			if (tableDetails.DefaultLoadType == LoadType.FullLoad)
			{
				string sqlTrunc = "TRUNCATE TABLE " + tableDetails.Name;
				SqlCommand cmd = new SqlCommand(sqlTrunc, targetConnection);
				cmd.ExecuteNonQuery();
			}
			else
			{
				string sqlQuery = string.Format(this.deleteQueryFormat, this.maxDeleteRecordCount, tableDetails.Name, tableDetails.PartialWhereQuery);
				SqlCommand cmd = new SqlCommand(sqlQuery, targetConnection);
				cmd.ExecuteNonQuery();
			}

			targetConnection.Close();
			targetConnection.Dispose();
		}

		/// <inheritdoc />
		public List<string> GetAllTables(string connectionString)
		{
			SqlConnection connection = new SqlConnection(connectionString);
			connection.Open();
			DataTable data = connection.GetSchema("Tables");
			var tables = data.Rows.Cast<DataRow>().Select(x => x[2].ToString()).OrderBy(x => x).ToList();
			connection.Close();
			connection.Dispose();
			return tables;
		}		

		/// <inheritdoc />
		public DataTable GetSourceData(string sourceConnectionString, TableConfiguration tableDetails)
		{
			DataTable table = new DataTable();

			SqlConnection sourceConnection = new SqlConnection(sourceConnectionString);
			//I assume you know better what is your connection string

			SqlDataAdapter adapter = null;
			if (tableDetails.DefaultLoadType == LoadType.FullLoad)
			{
				adapter = new SqlDataAdapter("SELECT * FROM " + tableDetails.Name + " (NOLOCK) ", sourceConnection);
			}
			else
			{
				adapter = new SqlDataAdapter("SELECT * FROM " + tableDetails.Name + " (NOLOCK) WHERE " + tableDetails.PartialWhereQuery, sourceConnection);
			}

			adapter.Fill(table);
			sourceConnection.Close();
			sourceConnection.Dispose();

			return table;
		}

		/// <inheritdoc />
		public void SaveToTargetTable(string targetConnectionString, TableConfiguration tableDetails, DataTable data)
		{
			SqlConnection targetConnection = new SqlConnection(targetConnectionString);
			targetConnection.Open();
			SqlBulkCopy bulkcopy = new SqlBulkCopy(targetConnection);
			bulkcopy.DestinationTableName = tableDetails.Name;
			bulkcopy.WriteToServer(data);
			targetConnection.Close();
			targetConnection.Dispose();
		}

		/// <inheritdoc />
		public void TestConnection(string connectionString)
		{
			using (SqlConnection connection = new SqlConnection(connectionString))
			{

				try
				{
					connection.Open();

				}
				catch (Exception ex)
				{
					ErrorLog.LogException(ex);
					throw;
				}
				finally
				{
					connection.Close();
				}
			}
		}
	}
}
