﻿// <copyright file="Resolver.cs" company="Ayvan">
// Copyright (c) 2019 All Rights Reserved
// </copyright>
// <author>UTKARSHLAPTOP\Utkarsh</author>
// <date>2019-08-18</date>

namespace DataMigrator.Common
{
	using DataMigrator.Contracts;
	using Unity;

	/// <summary>
	/// Defines the <see cref="Resolver" />
	/// </summary>
	public class Resolver : IResolver
	{
		/// <inheritdoc />
		public T Resolve<T>()
		{
			return UnityConfig.Container.Resolve<T>();
		}

		/// <inheritdoc />
		public T Resolve<T>(string key)
		{
			return UnityConfig.Container.Resolve<T>(key);
		}
	}
}
