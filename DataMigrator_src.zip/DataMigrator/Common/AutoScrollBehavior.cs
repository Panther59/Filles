﻿// <copyright file="AutoScrollBehavior.cs" company="Ayvan">
// Copyright (c) 2019 All Rights Reserved
// </copyright>
// <author>UTKARSHLAPTOP\Utkarsh</author>
// <date>2019-08-18</date>

namespace DataMigrator.Common
{
	using System.Windows;
	using System.Windows.Controls;

	/// <summary>
	/// Defines the <see cref="AutoScrollBehavior" />
	/// </summary>
	public static class AutoScrollBehavior
	{
		/// <summary>
		/// Defines the AutoScrollProperty
		/// </summary>
		public static readonly DependencyProperty AutoScrollProperty =
			DependencyProperty.RegisterAttached("AutoScroll", typeof(bool), typeof(AutoScrollBehavior), new PropertyMetadata(false, AutoScrollPropertyChanged));

		/// <summary>
		/// The AutoScrollPropertyChanged
		/// </summary>
		/// <param name="obj">The obj<see cref="DependencyObject"/></param>
		/// <param name="args">The args<see cref="DependencyPropertyChangedEventArgs"/></param>
		public static void AutoScrollPropertyChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
		{
			var scrollViewer = obj as ScrollViewer;
			if (scrollViewer != null && (bool)args.NewValue)
			{
				scrollViewer.ScrollChanged += ScrollViewer_ScrollChanged;
				scrollViewer.ScrollToEnd();
			}
			else
			{
				scrollViewer.ScrollChanged -= ScrollViewer_ScrollChanged;
			}
		}

		/// <summary>
		/// The GetAutoScroll
		/// </summary>
		/// <param name="obj">The obj<see cref="DependencyObject"/></param>
		/// <returns>The <see cref="bool"/></returns>
		public static bool GetAutoScroll(DependencyObject obj)
		{
			return (bool)obj.GetValue(AutoScrollProperty);
		}

		/// <summary>
		/// The SetAutoScroll
		/// </summary>
		/// <param name="obj">The obj<see cref="DependencyObject"/></param>
		/// <param name="value">The value<see cref="bool"/></param>
		public static void SetAutoScroll(DependencyObject obj, bool value)
		{
			obj.SetValue(AutoScrollProperty, value);
		}

		/// <summary>
		/// The ScrollViewer_ScrollChanged
		/// </summary>
		/// <param name="sender">The sender<see cref="object"/></param>
		/// <param name="e">The e<see cref="ScrollChangedEventArgs"/></param>
		private static void ScrollViewer_ScrollChanged(object sender, ScrollChangedEventArgs e)
		{
			// Only scroll to bottom when the extent changed. Otherwise you can't scroll up
			if (e.ExtentHeightChange != 0)
			{
				var scrollViewer = sender as ScrollViewer;
				scrollViewer?.ScrollToBottom();
			}
		}
	}
}
