﻿// <copyright file="LoadType.cs" company="Ayvan">
// Copyright (c) 2019 All Rights Reserved
// </copyright>
// <author>UTKARSHLAPTOP\Utkarsh</author>
// <date>2019-08-18</date>

namespace DataMigrator.Common
{
	/// <summary>
	/// Defines the LoadType
	/// </summary>
	public enum LoadType
	{
		/// <summary>
		/// Defines the FullLoad
		/// </summary>
		FullLoad,

		/// <summary>
		/// Defines the PartialLoad
		/// </summary>
		PartialLoad
	}
}
