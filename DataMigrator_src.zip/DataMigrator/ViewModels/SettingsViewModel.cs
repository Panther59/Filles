﻿// <copyright file="SettingsViewModel.cs" company="Ayvan">
// Copyright (c) 2019 All Rights Reserved
// </copyright>
// <author>UTKARSHLAPTOP\Utkarsh</author>
// <date>2019-08-19</date>

namespace DataMigrator.ViewModels
{
	using Ayvan.MVVMBase.Entities;
	using DataMigrator.Contracts;
	using DataMigrator.Models;
	using MaterialDesignThemes.Wpf;

	/// <summary>
	/// Defines the <see cref="SettingsViewModel" />
	/// </summary>
	public class SettingsViewModel : BaseViewModel
	{
		/// <summary>
		/// Defines the appDataHelper
		/// </summary>
		private readonly IAppDataHelper appDataHelper;

		/// <summary>
		/// The maxDeleteRecordCount field
		/// </summary>
		private int maxDeleteRecordCount;

		/// <summary>
		/// The maxInsertRecordCount field
		/// </summary>
		private int maxInsertRecordCount;

		/// <summary>
		/// The saveSettingsCommand field
		/// </summary>
		private RelayCommand saveSettingsCommand;

		/// <summary>
		/// Initializes a new instance of the <see cref="SettingsViewModel"/> class.
		/// </summary>
		/// <param name="appDataHelper">The appDataHelper<see cref="IAppDataHelper"/></param>
		public SettingsViewModel(IAppDataHelper appDataHelper)
		{
			this.appDataHelper = appDataHelper;
			this.Initialize();
		}

		/// <summary>
		/// Gets or sets the MaxDeleteRecordCount
		/// </summary>
		public int MaxDeleteRecordCount
		{
			get
			{
				return this.maxDeleteRecordCount;
			}

			set
			{
				this.maxDeleteRecordCount = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets or sets the MaxInsertRecordCount
		/// </summary>
		public int MaxInsertRecordCount
		{
			get
			{
				return this.maxInsertRecordCount;
			}

			set
			{
				this.maxInsertRecordCount = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets or sets the MessageQueue
		/// </summary>
		public SnackbarMessageQueue MessageQueue { get; set; } = new SnackbarMessageQueue();

		/// <summary>
		/// Gets the SaveSettingsCommand
		/// </summary>
		public RelayCommand SaveSettingsCommand
		{
			get
			{
				if (this.saveSettingsCommand == null)
				{
					this.saveSettingsCommand = new RelayCommand(command => this.ExecuteSaveSettings(), can => this.CanSaveSettingsExecute());
				}

				return this.saveSettingsCommand;
			}
		}

		/// <summary>
		/// The ViewOpened
		/// </summary>
		public override void ViewOpened()
		{
			this.Initialize();
		}

		/// <summary>
		/// Determines whether SaveSettings can be executed or not
		/// </summary>
		/// <returns>True if can execute or false</returns>
		private bool CanSaveSettingsExecute()
		{
			return this.MaxDeleteRecordCount > 0 && this.MaxInsertRecordCount > 0;
		}

		/// <summary>
		/// Executes SaveSettings
		/// </summary>
		private void ExecuteSaveSettings()
		{
			var settings = new Settings
			{
				MaxDeleteRecordCount = this.MaxDeleteRecordCount,
				MaxInsertRecordCount = this.MaxInsertRecordCount
			};

			this.appDataHelper.Settings = settings;
			this.MessageQueue.Enqueue("Settings saved");
		}

		/// <summary>
		/// The Initialize
		/// </summary>
		private void Initialize()
		{
			var settings = this.appDataHelper.Settings;
			this.MaxDeleteRecordCount = settings.MaxDeleteRecordCount;
			this.MaxInsertRecordCount = settings.MaxInsertRecordCount;
		}
	}
}
