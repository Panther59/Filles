﻿// <copyright file="DatabasesViewModel.cs" company="Ayvan">
// Copyright (c) 2019 All Rights Reserved
// </copyright>
// <author>UTKARSHLAPTOP\Utkarsh</author>
// <date>2019-08-17</date>

namespace DataMigrator.ViewModels
{
	using System;
	using System.Collections.Generic;
	using System.Collections.ObjectModel;
	using System.Linq;
	using Ayvan.ErrorLogger;
	using Ayvan.MVVMBase.Entities;
	using DataMigrator.Common;
	using DataMigrator.Contracts;
	using MaterialDesignThemes.Wpf;

	/// <summary>
	/// Defines the <see cref="DatabasesViewModel" />
	/// </summary>
	public class DatabasesViewModel : BaseViewModel
	{
		/// <summary>
		/// Defines the appHelper
		/// </summary>
		private readonly IAppDataHelper appHelper;
		private readonly ISqlServerHelper sqlServerHelper;

		/// <summary>
		/// The applications field
		/// </summary>
		private List<ApplicationViewModel> applications;

		/// <summary>
		/// The closeDatabaseDialogCommand field
		/// </summary>
		private RelayCommand closeDatabaseDialogCommand;

		/// <summary>
		/// The database field
		/// </summary>
		private DatabaseViewModel database;

		/// <summary>
		/// The databases field
		/// </summary>
		private ObservableCollection<DatabaseViewModel> databases;

		/// <summary>
		/// The dbMessageQueue field
		/// </summary>
		private SnackbarMessageQueue dbMessageQueue;

		/// <summary>
		/// The deleteDatabaseCommand field
		/// </summary>
		private RelayCommand<DatabaseViewModel> deleteDatabaseCommand;

		/// <summary>
		/// The editDatabaseCommand field
		/// </summary>
		private RelayCommand<DatabaseViewModel> editDatabaseCommand;

		/// <summary>
		/// Defines the editIndex
		/// </summary>
		private int editIndex;

		/// <summary>
		/// The isDatabaseDialogOpen field
		/// </summary>
		private bool isDatabaseDialogOpen;

		/// <summary>
		/// Defines the isEditMode
		/// </summary>
		private bool isEditMode;

		/// <summary>
		/// The openDatabaseDialogCommand field
		/// </summary>
		private RelayCommand openDatabaseDialogCommand;

		/// <summary>
		/// The saveDatabaseCommand field
		/// </summary>
		private RelayCommand saveDatabaseCommand;

		/// <summary>
		/// The testConnectionCommand field
		/// </summary>
		private RelayCommand testConnectionCommand;

		/// <summary>
		/// Initializes a new instance of the <see cref="DatabasesViewModel"/> class.
		/// </summary>
		public DatabasesViewModel(IAppDataHelper appDataHelper, ISqlServerHelper sqlServerHelper)
		{
			this.appHelper = appDataHelper;
			this.sqlServerHelper = sqlServerHelper;
			this.LoadData();
		}

		/// <summary>
		/// Gets or sets the Applications
		/// </summary>
		public List<ApplicationViewModel> Applications
		{
			get
			{
				return this.applications;
			}

			set
			{
				this.applications = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets the CloseDatabaseDialogCommand
		/// </summary>
		public RelayCommand CloseDatabaseDialogCommand
		{
			get
			{
				if (this.closeDatabaseDialogCommand == null)
				{
					this.closeDatabaseDialogCommand = new RelayCommand(command => this.ExecuteCloseDatabaseDialog());
				}

				return this.closeDatabaseDialogCommand;
			}
		}

		/// <summary>
		/// Gets or sets the Database
		/// </summary>
		public DatabaseViewModel Database
		{
			get
			{
				return this.database;
			}

			set
			{
				this.database = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets or sets the Databases
		/// </summary>
		public ObservableCollection<DatabaseViewModel> Databases
		{
			get
			{
				return this.databases;
			}

			set
			{
				this.databases = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets or sets the DBMessageQueue
		/// </summary>
		public SnackbarMessageQueue DBMessageQueue
		{
			get
			{
				return this.dbMessageQueue;
			}

			set
			{
				this.dbMessageQueue = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets the DeleteDatabaseCommand
		/// </summary>
		public RelayCommand<DatabaseViewModel> DeleteDatabaseCommand
		{
			get
			{
				if (this.deleteDatabaseCommand == null)
				{
					this.deleteDatabaseCommand = new RelayCommand<DatabaseViewModel>(command => this.ExecuteDeleteDatabase(command));
				}

				return this.deleteDatabaseCommand;
			}
		}

		/// <summary>
		/// Gets the EditDatabaseCommand
		/// </summary>
		public RelayCommand<DatabaseViewModel> EditDatabaseCommand
		{
			get
			{
				if (this.editDatabaseCommand == null)
				{
					this.editDatabaseCommand = new RelayCommand<DatabaseViewModel>(command => this.ExecuteEditDatabase(command));
				}

				return this.editDatabaseCommand;
			}
		}

		/// <summary>
		/// Gets or sets a value indicating whether IsDatabaseDialogOpen
		/// </summary>
		public bool IsDatabaseDialogOpen
		{
			get
			{
				return this.isDatabaseDialogOpen;
			}

			set
			{
				this.isDatabaseDialogOpen = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets the OpenDatabaseDialogCommand
		/// </summary>
		public RelayCommand OpenDatabaseDialogCommand
		{
			get
			{
				if (this.openDatabaseDialogCommand == null)
				{
					this.openDatabaseDialogCommand = new RelayCommand(command => this.ExecuteOpenDatabaseDialog());
				}

				return this.openDatabaseDialogCommand;
			}
		}

		/// <summary>
		/// Gets the SaveDatabaseCommand
		/// </summary>
		public RelayCommand SaveDatabaseCommand
		{
			get
			{
				if (this.saveDatabaseCommand == null)
				{
					this.saveDatabaseCommand = new RelayCommand(command => this.ExecuteSaveDatabase(), can => this.CanSaveDatabaseExecute());
				}

				return this.saveDatabaseCommand;
			}
		}

		/// <summary>
		/// Gets the TestConnectionCommand
		/// </summary>
		public RelayCommand TestConnectionCommand
		{
			get
			{
				if (this.testConnectionCommand == null)
				{
					this.testConnectionCommand = new RelayCommand(command => this.ExecuteTestConnection(), can => this.CanTestConnectionExecute());
				}

				return this.testConnectionCommand;
			}
		}

		/// <summary>
		/// The ViewOpened
		/// </summary>
		public override void ViewOpened()
		{
			this.LoadData();
		}

		/// <summary>
		/// Determines whether SaveDatabase can be executed or not
		/// </summary>
		/// <returns>True if can execute or false</returns>
		private bool CanSaveDatabaseExecute()
		{
			return this.Database?.Application != null &&
				string.IsNullOrEmpty(this.Database?.Name) == false &&
				string.IsNullOrEmpty(this.Database?.ConnectionString) == false;
		}

		/// <summary>
		/// Determines whether TestConnection can be executed or not
		/// </summary>
		/// <returns>True if can execute or false</returns>
		private bool CanTestConnectionExecute()
		{
			return this.Database?.Application != null &&
				string.IsNullOrEmpty(this.Database?.Name) == false &&
				string.IsNullOrEmpty(this.Database?.ConnectionString) == false;
		}

		/// <summary>
		/// Executes CloseDatabaseDialog
		/// </summary>
		private void ExecuteCloseDatabaseDialog()
		{
			this.IsDatabaseDialogOpen = false;
		}

		/// <summary>
		/// Executes DeleteDatabase
		/// </summary>
		/// <param name="input">The <see cref="DatabaseViewModel"/></param>
		private void ExecuteDeleteDatabase(DatabaseViewModel input)
		{
			this.Databases.Remove(input);
			this.appHelper.Databases = this.Databases.ToList();
		}

		/// <summary>
		/// Executes EditDatabase
		/// </summary>
		/// <param name="input">The <see cref="DatabaseViewModel"/></param>
		private void ExecuteEditDatabase(DatabaseViewModel input)
		{
			this.isEditMode = true;
			this.editIndex = this.Databases.IndexOf(input);
			this.Database = input;
			this.IsDatabaseDialogOpen = true;
		}

		/// <summary>
		/// Executes OpenDatabaseDialog
		/// </summary>
		private void ExecuteOpenDatabaseDialog()
		{
			this.isEditMode = false;
			this.Database = new DatabaseViewModel();
			this.IsDatabaseDialogOpen = true;
		}

		/// <summary>
		/// Executes SaveDatabase
		/// </summary>
		private void ExecuteSaveDatabase()
		{
			if (this.isEditMode && this.editIndex > -1 && this.editIndex < this.Databases.Count)
			{
				this.Databases.RemoveAt(this.editIndex);
				this.Databases.Insert(this.editIndex, this.Database);
			}
			else
			{
				this.Databases.Add(this.Database);
			}

			this.IsDatabaseDialogOpen = false;
			this.appHelper.Databases = this.Databases.ToList();
		}

		/// <summary>
		/// Executes TestConnection
		/// </summary>
		private void ExecuteTestConnection()
		{
			this.DBMessageQueue = new SnackbarMessageQueue();
			try
			{
				this.sqlServerHelper.TestConnection(this.Database.ConnectionString);
				this.DBMessageQueue.Enqueue("Test connection successful.");
			}
			catch (Exception ex)
			{
				ErrorLog.LogException(ex);
				this.DBMessageQueue.Enqueue("Error in Connection" + Environment.NewLine + ex.Message);
			}
		}

		/// <summary>
		/// The LoadData
		/// </summary>
		private void LoadData()
		{
			var dbs = this.appHelper.Databases;
			this.Databases = new ObservableCollection<DatabaseViewModel>(dbs ?? new System.Collections.Generic.List<DatabaseViewModel>());
			this.Applications = this.appHelper.Applications;
		}
	}
}
