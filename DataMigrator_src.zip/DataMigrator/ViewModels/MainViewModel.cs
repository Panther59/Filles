﻿// <copyright file="MainViewModel.cs" company="Ayvan">
// Copyright (c) 2019 All Rights Reserved
// </copyright>
// <author>UTKARSHLAPTOP\Utkarsh</author>
// <date>2019-08-17</date>

namespace DataMigrator.ViewModels
{
	using System.Collections.ObjectModel;
	using Ayvan.MVVMBase.Entities;
	using DataMigrator.Common;
	using DataMigrator.Contracts;

	/// <summary>
	/// Defines the <see cref="MainViewModel" />
	/// </summary>
	public class MainViewModel : BaseViewModel
	{
		/// <summary>
		/// Defines the itemContainerResolver
		/// </summary>
		private readonly IItemContainerResolver itemContainerResolver;

		/// <summary>
		/// Defines the resolver
		/// </summary>
		private readonly IResolver resolver;

		/// <summary>
		/// The isMenuOpen field
		/// </summary>
		private bool isMenuOpen;

		/// <summary>
		/// The items field
		/// </summary>
		private ObservableCollection<IItemContainer> items;

		/// <summary>
		/// The mainContent field
		/// </summary>
		private IItemContainer mainContent;

		/// <summary>
		/// The viewSelectedCommand field
		/// </summary>
		private RelayCommand viewSelectedCommand;

		/// <summary>
		/// Initializes a new instance of the <see cref="MainViewModel"/> class.
		/// </summary>
		/// <param name="resolver">The resolver<see cref="IResolver"/></param>
		/// <param name="itemContainerResolver">The itemContainerResolver<see cref="IItemContainerResolver"/></param>
		public MainViewModel(IResolver resolver, IItemContainerResolver itemContainerResolver)
		{
			this.resolver = resolver;
			this.itemContainerResolver = itemContainerResolver;

			this.Items = new ObservableCollection<IItemContainer>()
			{
				this.itemContainerResolver.GetView(Screens.Home.ToString()),
				this.itemContainerResolver.GetView(Screens.Applications.ToString()),
				this.itemContainerResolver.GetView(Screens.Databases.ToString()),
				this.itemContainerResolver.GetView(Screens.Tables.ToString()),
				this.itemContainerResolver.GetView(Screens.Settings.ToString()),
			};

			this.MainContent = this.Items[0];
		}

		/// <summary>
		/// Gets or sets a value indicating whether IsMenuOpen
		/// </summary>
		public bool IsMenuOpen
		{
			get
			{
				return this.isMenuOpen;
			}

			set
			{
				this.isMenuOpen = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets or sets the Items
		/// </summary>
		public ObservableCollection<IItemContainer> Items
		{
			get
			{
				return this.items;
			}

			set
			{
				this.items = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets or sets the MainContent
		/// </summary>
		public IItemContainer MainContent
		{
			get
			{
				return this.mainContent;
			}

			set
			{
				this.mainContent = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets the ViewSelectedCommand
		/// </summary>
		public RelayCommand ViewSelectedCommand
		{
			get
			{
				if (this.viewSelectedCommand == null)
				{
					this.viewSelectedCommand = new RelayCommand(command => this.ExecuteViewSelected());
				}

				return this.viewSelectedCommand;
			}
		}

		/// <summary>
		/// Executes ViewSelected
		/// </summary>
		private void ExecuteViewSelected()
		{
			this.MainContent.ViewModel?.ViewOpened();
			this.IsMenuOpen = false;
		}
	}
}
