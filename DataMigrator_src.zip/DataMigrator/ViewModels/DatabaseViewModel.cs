﻿// <copyright file="DatabaseViewModel.cs" company="Ayvan">
// Copyright (c) 2019 All Rights Reserved
// </copyright>
// <author>UTKARSHLAPTOP\Utkarsh</author>
// <date>2019-08-17</date>

namespace DataMigrator.ViewModels
{
	using DataMigrator.Models;

	/// <summary>
	/// Defines the <see cref="DatabaseViewModel" />
	/// </summary>
	public class DatabaseViewModel : BaseViewModel
	{
		/// <summary>
		/// The application field
		/// </summary>
		private ApplicationViewModel application;

		/// <summary>
		/// The category field
		/// </summary>
		private DatabaseCategoryType category;

		/// <summary>
		/// The connectionString field
		/// </summary>
		private string connectionString;

		/// <summary>
		/// The name field
		/// </summary>
		private string name;

		/// <summary>
		/// Gets or sets the Application
		/// </summary>
		public ApplicationViewModel Application
		{
			get
			{
				return this.application;
			}

			set
			{
				this.application = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets or sets the Category
		/// </summary>
		public DatabaseCategoryType Category
		{
			get
			{
				return this.category;
			}

			set
			{
				this.category = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets or sets the ConnectionString
		/// </summary>
		public string ConnectionString
		{
			get
			{
				return this.connectionString;
			}

			set
			{
				this.connectionString = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets or sets the Name
		/// </summary>
		public string Name
		{
			get
			{
				return this.name;
			}

			set
			{
				this.name = value;
				this.RaisePropertyChanged();
			}
		}
	}
}
