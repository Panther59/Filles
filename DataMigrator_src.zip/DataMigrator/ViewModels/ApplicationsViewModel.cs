﻿// <copyright file="ApplicationsViewModel.cs" company="Ayvan">
// Copyright (c) 2019 All Rights Reserved
// </copyright>
// <author>UTKARSHLAPTOP\Utkarsh</author>
// <date>2019-08-17</date>

namespace DataMigrator.ViewModels
{
	using System.Collections.Generic;
	using System.Collections.ObjectModel;
	using System.Linq;
	using Ayvan.MVVMBase.Entities;
	using DataMigrator.Common;
	using DataMigrator.Contracts;
	using MaterialDesignThemes.Wpf;

	/// <summary>
	/// Defines the <see cref="ApplicationsViewModel" />
	/// </summary>
	public class ApplicationsViewModel : BaseViewModel
	{
		/// <summary>
		/// Defines the helper
		/// </summary>
		private readonly IAppDataHelper helper;

		/// <summary>
		/// Defines the addNewApplicationCommand
		/// </summary>
		private RelayCommand addNewApplicationCommand;

		/// <summary>
		/// Defines the applications
		/// </summary>
		private ObservableCollection<ApplicationViewModel> applications;

		/// <summary>
		/// Defines the deleteApplicationCommand
		/// </summary>
		private RelayCommand<ApplicationViewModel> deleteApplicationCommand;

		/// <summary>
		/// The messageQueue field
		/// </summary>
		private SnackbarMessageQueue messageQueue;

		/// <summary>
		/// The saveApplicationsCommand field
		/// </summary>
		private RelayCommand saveApplicationsCommand;

		/// <summary>
		/// Initializes a new instance of the <see cref="ApplicationsViewModel"/> class.
		/// </summary>
		public ApplicationsViewModel(IAppDataHelper appDataHelper)
		{
			this.helper = appDataHelper;
			this.LoadData();
		}

		/// <summary>
		/// Gets the AddNewApplicationCommand
		/// </summary>
		public RelayCommand AddNewApplicationCommand
		{
			get
			{
				if (this.addNewApplicationCommand == null)
				{
					this.addNewApplicationCommand = new RelayCommand(command => this.ExecuteAddNewApplication());
				}

				return this.addNewApplicationCommand;
			}
		}

		/// <summary>
		/// Gets or sets the Applications
		/// </summary>
		public ObservableCollection<ApplicationViewModel> Applications
		{
			get
			{
				return this.applications;
			}

			set
			{
				this.applications = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets the DeleteApplicationCommand
		/// </summary>
		public RelayCommand<ApplicationViewModel> DeleteApplicationCommand
		{
			get
			{
				if (this.deleteApplicationCommand == null)
				{
					this.deleteApplicationCommand = new RelayCommand<ApplicationViewModel>(command => this.ExecuteDeleteApplication(command));
				}

				return this.deleteApplicationCommand;
			}
		}

		/// <summary>
		/// Gets or sets the MessageQueue
		/// </summary>
		public SnackbarMessageQueue MessageQueue
		{
			get
			{
				return this.messageQueue;
			}

			set
			{
				this.messageQueue = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets the SaveApplicationsCommand
		/// </summary>
		public RelayCommand SaveApplicationsCommand
		{
			get
			{
				if (this.saveApplicationsCommand == null)
				{
					this.saveApplicationsCommand = new RelayCommand(command => this.ExecuteSaveApplications());
				}

				return this.saveApplicationsCommand;
			}
		}

		/// <summary>
		/// The ViewOpened
		/// </summary>
		public override void ViewOpened()
		{
			this.LoadData();
		}

		/// <summary>
		/// The ExecuteAddNewApplication
		/// </summary>
		private void ExecuteAddNewApplication()
		{
			if (this.Applications == null)
			{
				this.Applications = new ObservableCollection<ApplicationViewModel>();
			}

			this.Applications.Add(new ApplicationViewModel());
		}

		/// <summary>
		/// The ExecuteDeleteApplication
		/// </summary>
		/// <param name="input">The input<see cref="ApplicationViewModel"/></param>
		private void ExecuteDeleteApplication(ApplicationViewModel input)
		{
			this.Applications.Remove(input);
		}

		/// <summary>
		/// Executes SaveApplications
		/// </summary>
		private void ExecuteSaveApplications()
		{
			var applications = this.Applications
				.Where(x => string.IsNullOrWhiteSpace(x.Name) == false)
				.Select(x => new ApplicationViewModel() { Name = x.Name.Trim() })
				.ToList();

			this.helper.Applications = applications;
			this.Applications = new ObservableCollection<ApplicationViewModel>(applications);
			this.MessageQueue.Enqueue("Applications saved successfully");
		}

		/// <summary>
		/// The LoadData
		/// </summary>
		private void LoadData()
		{
			this.MessageQueue = new SnackbarMessageQueue();
			this.Applications = new ObservableCollection<ApplicationViewModel>(helper.Applications ?? new List<ApplicationViewModel>());
		}
	}
}
