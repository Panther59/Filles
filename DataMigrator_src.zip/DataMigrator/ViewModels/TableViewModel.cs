﻿// <copyright file="TableViewModel.cs" company="Ayvan">
// Copyright (c) 2019 All Rights Reserved
// </copyright>
// <author>UTKARSHLAPTOP\Utkarsh</author>
// <date>2019-08-18</date>

namespace DataMigrator.ViewModels
{
	using DataMigrator.Common;

	/// <summary>
	/// Defines the <see cref="TableViewModel" />
	/// </summary>
	public class TableViewModel : BaseViewModel
	{
		/// <summary>
		/// The defaultLoadType field
		/// </summary>
		private LoadType defaultLoadType;

		/// <summary>
		/// The name field
		/// </summary>
		private string name;

		/// <summary>
		/// The partialWhereQuery field
		/// </summary>
		private string partialWhereQuery;

		/// <summary>
		/// Gets or sets the DefaultLoadType
		/// </summary>
		public LoadType DefaultLoadType
		{
			get
			{
				return this.defaultLoadType;
			}

			set
			{
				this.defaultLoadType = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets or sets the Name
		/// </summary>
		public string Name
		{
			get
			{
				return this.name;
			}

			set
			{
				this.name = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets or sets the PartialWhereQuery
		/// </summary>
		public string PartialWhereQuery
		{
			get
			{
				return this.partialWhereQuery;
			}

			set
			{
				this.partialWhereQuery = value;
				this.RaisePropertyChanged();
			}
		}
	}
}
