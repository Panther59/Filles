﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataMigrator.ViewModels
{
	public abstract class BaseViewModel : Ayvan.MVVMBase.Entities.BaseViewModel
	{
		public virtual void ViewOpened()
		{
		}
	}
}
