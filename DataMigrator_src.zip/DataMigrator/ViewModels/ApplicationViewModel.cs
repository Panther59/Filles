﻿// <copyright file="ApplicationViewModel.cs" company="Ayvan">
// Copyright (c) 2019 All Rights Reserved
// </copyright>
// <author>UTKARSHLAPTOP\Utkarsh</author>
// <date>2019-08-18</date>

namespace DataMigrator.ViewModels
{
	/// <summary>
	/// Defines the <see cref="ApplicationViewModel" />
	/// </summary>
	public class ApplicationViewModel : BaseViewModel
	{
		/// <summary>
		/// The name field
		/// </summary>
		private string name;

		/// <summary>
		/// Gets or sets the Name
		/// </summary>
		public string Name
		{
			get
			{
				return this.name;
			}

			set
			{
				this.name = value;
				this.RaisePropertyChanged();
			}
		}
	}
}
