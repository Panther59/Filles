﻿// <copyright file="ItemContainer.cs" company="Ayvan">
// Copyright (c) 2019 All Rights Reserved
// </copyright>
// <author>UTKARSHLAPTOP\Utkarsh</author>
// <date>2019-08-17</date>

namespace DataMigrator.Controls
{
	using System.ComponentModel;
	using System.Runtime.CompilerServices;
	using System.Windows.Controls;
	using DataMigrator.Contracts;
	using DataMigrator.ViewModels;

	public class ItemContainerResolver : IItemContainerResolver
	{
		/// <summary>
		/// Defines the resolver
		/// </summary>
		private readonly IResolver resolver;

		/// <summary>
		/// Initializes a new instance of the <see cref="ItemContainer{Tview}"/> class.
		/// </summary>
		/// <param name="resolver">The resolver<see cref="IResolver"/></param>
		public ItemContainerResolver(IResolver resolver)
		{
			this.resolver = resolver;
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="ItemContainer{Tview}"/> class.
		/// </summary>
		/// <param name="name">The name<see cref="string"/></param>
		/// <returns>The <see cref="IItemContainer"/></returns>
		public IItemContainer GetView(string name)
		{
			var container = this.resolver.Resolve<IItemContainer>();
			var uc = this.resolver.Resolve<UserControl>(name);
			var vm = this.resolver.Resolve<BaseViewModel>(name);
			uc.DataContext = vm;
			container.Name = name;
			container.Content = uc;
			container.ViewModel = vm;

			return container;
		}
	}

	/// <summary>
	/// Defines the <see cref="ItemContainer" />
	/// </summary>
	public class ItemContainer : INotifyPropertyChanged, IItemContainer
	{
		/// <summary>
		/// The content field
		/// </summary>
		private object content;

		/// <summary>
		/// The name field
		/// </summary>
		private string name;

		/// <summary>
		/// The viewModel field
		/// </summary>
		private BaseViewModel viewModel;

		/// <summary>
		/// Initializes a new instance of the <see cref="ItemContainer"/> class.
		/// </summary>
		public ItemContainer()
		{
		}

		/// <summary>
		/// Defines the PropertyChanged
		/// </summary>
		public event PropertyChangedEventHandler PropertyChanged;

		/// <summary>
		/// Gets or sets the Content
		/// </summary>
		public object Content
		{
			get
			{
				return this.content;
			}

			set
			{
				this.content = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets or sets the Name
		/// </summary>
		public string Name
		{
			get
			{
				return this.name;
			}

			set
			{
				this.name = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets or sets the ViewModel
		/// </summary>
		public BaseViewModel ViewModel
		{
			get
			{
				return this.viewModel;
			}

			set
			{
				this.viewModel = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// The RaisePropertyChanged
		/// </summary>
		/// <param name="propertyName">The propertyName<see cref="string"/></param>
		private void RaisePropertyChanged([CallerMemberName] string propertyName = "")
		{
			this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
		}
	}
}
