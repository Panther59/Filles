﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Ayvan.WPF.MaterialThemes;
using DataMigrator.Common;
using DataMigrator.Contracts;
using DataMigrator.ViewModels;

namespace DataMigrator.Controls
{
	/// <summary>
	/// Interaction logic for MainView.xaml
	/// </summary>
	public partial class MainView : UserControl
	{
		private readonly IResolver resolver;

		public MainView(IResolver resolver)
		{
			InitializeComponent();
			this.Loaded += this.MainView_Loaded;
			this.resolver = resolver;
		}

		private void MainView_Loaded(object sender, RoutedEventArgs e)
		{
			this.DataContext = this.resolver.Resolve<BaseViewModel>(Screens.Main.ToString());
		}

		private void Button_Click(object sender, RoutedEventArgs e)
		{
			ThemeWindow themeWindow = this.resolver.Resolve<ThemeWindow>(); ;
			themeWindow.ShowDialog();
		}
	}
}
