﻿// <copyright file="AppTablesConfiguration.cs" company="Ayvan">
// Copyright (c) 2019 All Rights Reserved
// </copyright>
// <author>UTKARSHLAPTOP\Utkarsh</author>
// <date>2019-08-18</date>

namespace DataMigrator.Models
{
	using System.Collections.Generic;
	using DataMigrator.Common;

	/// <summary>
	/// Defines the <see cref="AppTablesConfiguration" />
	/// </summary>
	public class AppTablesConfiguration
	{
		/// <summary>
		/// Gets or sets the Application
		/// </summary>
		public string Application { get; set; }

		/// <summary>
		/// Gets or sets the Tables
		/// </summary>
		public List<TableConfiguration> Tables { get; set; }
	}

	/// <summary>
	/// Defines the <see cref="TableConfiguration" />
	/// </summary>
	public class TableConfiguration
	{
		/// <summary>
		/// Gets or sets the DefaultLoadType
		/// </summary>
		public LoadType DefaultLoadType { get; set; }

		/// <summary>
		/// Gets or sets the Name
		/// </summary>
		public string Name { get; set; }

		/// <summary>
		/// Gets or sets the PartialWhereQuery
		/// </summary>
		public string PartialWhereQuery { get; set; }
	}
}
