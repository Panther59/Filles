﻿// <copyright file="Settings.cs" company="Ayvan">
// Copyright (c) 2019 All Rights Reserved
// </copyright>
// <author>UTKARSHLAPTOP\Utkarsh</author>
// <date>2019-08-19</date>

namespace DataMigrator.Models
{
	/// <summary>
	/// Defines the <see cref="Settings" />
	/// </summary>
	public class Settings
	{
		/// <summary>
		/// Gets or sets the MaxDeleteRecordCount
		/// </summary>
		public int MaxDeleteRecordCount { get; set; }

		/// <summary>
		/// Gets or sets the MaxInsertRecordCount
		/// </summary>
		public int MaxInsertRecordCount { get; set; }
	}
}
