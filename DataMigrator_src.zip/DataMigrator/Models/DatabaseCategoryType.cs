﻿// <copyright file="DatabaseCategoryType.cs" company="Ayvan">
// Copyright (c) 2019 All Rights Reserved
// </copyright>
// <author>UTKARSHLAPTOP\Utkarsh</author>
// <date>2019-08-17</date>

namespace DataMigrator.Models
{
	/// <summary>
	/// Defines the DatabaseCategoryType
	/// </summary>
	public enum DatabaseCategoryType
	{
		/// <summary>
		/// Defines the DEV
		/// </summary>
		DEV,

		/// <summary>
		/// Defines the QA
		/// </summary>
		QA,

		/// <summary>
		/// Defines the TRN
		/// </summary>
		TRN,

		/// <summary>
		/// Defines the PROD
		/// </summary>
		PROD
	}
}
