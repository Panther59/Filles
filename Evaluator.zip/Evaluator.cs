﻿// <copyright file="MethodValidator.cs" company="Ayvan">
// Copyright (c) 2020 All Rights Reserved
// </copyright>
// <author>UTKARSHLAPTOP\Utkarsh</author>
// <date>2020-03-28</date>

namespace Web7.Tests
{
	using FakeItEasy;
	using NUnit.Framework;
	using System;
	using System.Linq.Expressions;

	/// <summary>
	/// Defines the <see cref="MethodValidator" />.
	/// </summary>
	public class Evaluator
	{
		/// <summary>
		/// The EnsureMethodCalled.
		/// </summary>
		/// <param name="expression">The expression<see cref="Expression{Action}"/> which needs to be evaluated.</param>
		/// <param name="times">The times<see cref="Times"/> it has been called.</param>
		/// <param name="count">The count<see cref="int"/> for specific time.</param>
		public static void EnsureMethodCalled(Expression<Action> expression, Times times, int count = 0)
		{
			switch (times)
			{
				case Times.Never:
					A.CallTo(expression).MustNotHaveHappened();
					break;
				case Times.Exactly:
					A.CallTo(expression).MustHaveHappened(count, FakeItEasy.Times.Exactly);
					break;
				case Times.Atleast:
					A.CallTo(expression).MustHaveHappened(count, FakeItEasy.Times.OrMore);
					break;
				case Times.AtMost:
					A.CallTo(expression).MustHaveHappened(count, FakeItEasy.Times.OrLess);
					break;
				default:
					throw new Exception("Unknown Evaluation");
			}
		}

		/// <summary>
		/// The EnsureMethodCalled.
		/// </summary>
		/// <typeparam name="T">.</typeparam>
		/// <param name="expression">The expression<see cref="Expression{Func{T}}"/> which needs to be evaluated.</param>
		/// <param name="times">The times<see cref="Times"/> it has been called.</param>
		/// <param name="count">The count<see cref="int"/> for specific time.</param>
		public static void EnsureMethodCalled<T>(Expression<Func<T>> expression, Times times, int count = 0)
		{
			switch (times)
			{
				case Times.Never:
					A.CallTo(expression).MustNotHaveHappened();
					break;
				case Times.Exactly:
					A.CallTo(expression).MustHaveHappened(count, FakeItEasy.Times.Exactly);
					break;
				case Times.Atleast:
					A.CallTo(expression).MustHaveHappened(count, FakeItEasy.Times.OrMore);
					break;
				case Times.AtMost:
					A.CallTo(expression).MustHaveHappened(count, FakeItEasy.Times.OrLess);
					break;
				default:
					throw new Exception("Unknown Evaluation");
			}
		}

		/// <summary>
		/// The EnsureThrowsException.
		/// </summary>
		/// <typeparam name="Texpcetion">The type of exception expected from action.</typeparam>
		/// <param name="action">The action<see cref="Action"/> which needs to be validated for exception.</param>
		public static void EnsureThrowsException<Texpcetion>(Action action)
			where Texpcetion : Exception
		{
			try
			{
				action();
				Assert.Pass($"No exception of type {nameof(Texpcetion)} was thrown");
			}
			catch (Exception ex)
			{
				if (ex is Texpcetion)
				{
					Assert.Pass($"Received expected exception of type {nameof(Texpcetion)}");
				}
				else
				{
					Assert.Pass($"Received type of exception {nameof(ex)}, expected was {nameof(Texpcetion)}");
				}
			}
		}

		/// <summary>
		/// The EnsureThrowsException.
		/// </summary>
		/// <param name="action">The action<see cref="Action"/> which needs to be validated for exception.</param>
		public static void EnsureThrowsException(Action action)
		{
			try
			{
				action();
				Assert.Pass($"No exceptioncwas thrown");
			}
			catch (Exception)
			{
				Assert.Pass($"Received expected exception.");
			}
		}
	}
}
