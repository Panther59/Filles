﻿// <copyright file="Composer.cs" company="Ayvan">
// Copyright (c) 2020 All Rights Reserved
// </copyright>
// <author>UTKARSHLAPTOP\Utkarsh</author>
// <date>2020-03-28</date>

namespace Web7.Tests
{
	using FakeItEasy;
	using System;
	using System.Linq.Expressions;
	using System.Threading.Tasks;

	/// <summary>
	/// Defines the <see cref="Composer" />.
	/// </summary>
	public static class Composer
	{
		/// <summary>
		/// The SetupLazyReturn.
		/// </summary>
		/// <typeparam name="T">.</typeparam>
		/// <param name="expression">The expression<see cref="Expression{Func{Task{T}}}"/>.</param>
		/// <param name="data">The data<see cref="T"/>.</param>
		public static void SetupLazyReturn<T>(Expression<Func<Task<T>>> expression, T data)
		{
			A.CallTo(expression).Returns(data);
		}

		/// <summary>
		/// The SetupLazyThrowException.
		/// </summary>
		/// <typeparam name="T">.</typeparam>
		/// <param name="expression">The expression<see cref="Expression{Func{Task{T}}}"/>.</param>
		/// <param name="ex">The ex<see cref="Exception"/>.</param>
		public static void SetupLazyThrowException<T>(Expression<Func<Task<T>>> expression, Exception ex = null)
		{
			A.CallTo(expression).Throws(GetException(ex));
		}

		/// <summary>
		/// The GetException.
		/// </summary>
		/// <param name="ex">The ex<see cref="Exception"/>.</param>
		/// <returns>The <see cref="Exception"/>.</returns>
		internal static Exception GetException(Exception ex)
		{
			return ex ?? new Exception();
		}
	}
}
