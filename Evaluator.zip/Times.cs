﻿// <copyright file="Times.cs" company="Ayvan">
// Copyright (c) 2020 All Rights Reserved
// </copyright>
// <author>UTKARSHLAPTOP\Utkarsh</author>
// <date>2020-03-29</date>

namespace Web7.Tests
{
	/// <summary>
	/// Defines the Times.
	/// </summary>
	public enum Times
	{
		/// <summary>
		/// Defines the Never.
		/// </summary>
		Never,
		/// <summary>
		/// Defines the Exactly.
		/// </summary>
		Exactly,
		/// <summary>
		/// Defines the Atleast.
		/// </summary>
		Atleast,
		/// <summary>
		/// Defines the AtMost.
		/// </summary>
		AtMost,
	}
}
