﻿// <copyright file="SqlServerHelper.cs" company="Ayvan">
// Copyright (c) 2019 All Rights Reserved
// </copyright>
// <author>UTKARSHLAPTOP\Utkarsh</author>
// <date>2019-08-18</date>

namespace DataMigrator.Common
{
	using System;
	using System.Collections.Generic;
	using System.Data;
	using System.Data.SqlClient;
	using System.Linq;
	using Ayvan.ErrorLogger;
	using DataMigrator.Contracts;
	using DataMigrator.Models;

	/// <summary>
	/// Defines the <see cref="SqlServerHelper" />
	/// </summary>
	public class SqlServerHelper : ISqlServerHelper
	{
		/// <summary>
		/// Defines the batchAction
		/// </summary>
		private Action<long> batchAction;

		/// <summary>
		/// Defines the deleteQueryFormat
		/// </summary>
		private string deleteQueryFormat = @"DELETE TOP ({0}) FROM {1} WHERE {2}";

		/// <summary>
		/// Initializes a new instance of the <see cref="SqlServerHelper"/> class.
		/// </summary>
		public SqlServerHelper()
		{
		}

		/// <inheritdoc />
		public void BulkTransfer(string sourceConnectionString, string targetConnectionString, Models.TableConfiguration tableDetails)
		{
			try
			{
				DataTable table = new DataTable();

				using (SqlConnection sourceConnection = new SqlConnection(sourceConnectionString))
				{
					using (SqlConnection targetConnection = new SqlConnection(targetConnectionString))
					{
						if (targetConnection.State != ConnectionState.Open)
						{
							targetConnection.Open();
						}
						//I assume you know better what is your connection string

						SqlDataAdapter adapter = null;
						if (tableDetails.DefaultLoadType == LoadType.FullLoad)
						{
							adapter = new SqlDataAdapter("SELECT * FROM " + tableDetails.Name + " (NOLOCK) ", sourceConnection);
						}
						else
						{
							adapter = new SqlDataAdapter("SELECT * FROM " + tableDetails.Name + " (NOLOCK) WHERE " + tableDetails.PartialWhereQuery, sourceConnection);
						}

						adapter.Fill(table);
						adapter.Dispose();

						if (tableDetails.DefaultLoadType == LoadType.FullLoad)
						{
							string sqlTrunc = "TRUNCATE TABLE " + tableDetails.Name;
							SqlCommand cmd = new SqlCommand(sqlTrunc, targetConnection);
							cmd.ExecuteNonQuery();
						}
						else
						{
							string sqlQuery = string.Format(this.deleteQueryFormat, tableDetails.Name, tableDetails.PartialWhereQuery);
							SqlCommand cmd = new SqlCommand(sqlQuery, targetConnection);
							cmd.ExecuteNonQuery();
						}

						using (SqlBulkCopy bulkcopy = new SqlBulkCopy(targetConnection))
						{
							bulkcopy.DestinationTableName = tableDetails.Name;
							bulkcopy.WriteToServer(table);
						}
					}
				}
			}
			catch (Exception ex)
			{
				ErrorLog.LogException(ex);
			}
		}

		/// <inheritdoc />
		public void ClearTargetData(string targetConnectionString, TableConfiguration tableDetails, int maxDeleteRecordCount, Action<long> batchAction)
		{
			using (SqlConnection targetConnection = new SqlConnection(targetConnectionString))
			{
				if (targetConnection.State != ConnectionState.Open)
				{
					targetConnection.Open();
				}

				if (tableDetails.DefaultLoadType == LoadType.FullLoad)
				{
					string sqlTrunc = "TRUNCATE TABLE " + tableDetails.Name;
					SqlCommand cmd = new SqlCommand(sqlTrunc, targetConnection);
					cmd.ExecuteNonQuery();
				}
				else
				{
					long rowsDeleted = 0;
					long totalRowsDeleted = 0;
					string sqlQuery = string.Format(this.deleteQueryFormat, maxDeleteRecordCount, tableDetails.Name, tableDetails.PartialWhereQuery);

					do
					{
						SqlCommand cmd = new SqlCommand(sqlQuery, targetConnection);
						rowsDeleted = (long)cmd.ExecuteNonQuery();
						totalRowsDeleted += rowsDeleted;
						batchAction?.Invoke(totalRowsDeleted);
					} while (rowsDeleted >= maxDeleteRecordCount);
				}
			}
		}

		/// <inheritdoc />
		public List<string> GetAllTables(string connectionString)
		{
			using (SqlConnection connection = new SqlConnection(connectionString))
			{
				if (connection.State != ConnectionState.Open)
				{
					connection.Open();
				}

				DataTable data = connection.GetSchema("Tables");
				var tables = data.Rows.Cast<DataRow>().Select(x => x[2].ToString()).OrderBy(x => x).ToList();
				return tables;
			}
		}

		/// <inheritdoc />
		public DataTable GetSourceData(string sourceConnectionString, TableConfiguration tableDetails)
		{
			DataTable table = new DataTable();

			using (SqlConnection sourceConnection = new SqlConnection(sourceConnectionString))
			{//I assume you know better what is your connection string

				SqlDataAdapter adapter = null;
				if (tableDetails.DefaultLoadType == LoadType.FullLoad)
				{
					adapter = new SqlDataAdapter("SELECT * FROM " + tableDetails.Name + " (NOLOCK) ", sourceConnection);
				}
				else
				{
					adapter = new SqlDataAdapter("SELECT * FROM " + tableDetails.Name + " (NOLOCK) WHERE " + tableDetails.PartialWhereQuery, sourceConnection);
				}

				adapter.Fill(table);
				adapter.Dispose();
				return table;
			}
		}

		/// <inheritdoc />
		public int GetTableDataCount(string connectionString, TableConfiguration tableDetails)
		{
			using (SqlConnection sourceConnection = new SqlConnection(connectionString))
			{
				//I assume you know better what is your connection string
				if (sourceConnection.State != ConnectionState.Open)
				{
					sourceConnection.Open();
				}
				SqlCommand command = null;
				if (tableDetails.DefaultLoadType == LoadType.FullLoad)
				{
					command = new SqlCommand("SELECT COUNT(1) FROM " + tableDetails.Name + " (NOLOCK) ", sourceConnection);
				}
				else
				{
					command = new SqlCommand("SELECT COUNT(1) FROM " + tableDetails.Name + " (NOLOCK) WHERE " + tableDetails.PartialWhereQuery, sourceConnection);
				}

				return (int)command.ExecuteScalar();
			}
		}

		/// <inheritdoc />
		public void SaveToTargetTable(string targetConnectionString, TableConfiguration tableDetails, DataTable data)
		{
			using (SqlConnection targetConnection = new SqlConnection(targetConnectionString))
			{
				if (targetConnection.State != ConnectionState.Open)
				{
					targetConnection.Open();
				}

				using (SqlBulkCopy bulkcopy = new SqlBulkCopy(targetConnection))
				{
					bulkcopy.DestinationTableName = tableDetails.Name;
					bulkcopy.WriteToServer(data);
				}
			}
		}

		/// <inheritdoc />
		public void TestConnection(string connectionString)
		{
			using (SqlConnection connection = new SqlConnection(connectionString))
			{
				try
				{
					connection.Open();

				}
				catch (Exception ex)
				{
					ErrorLog.LogException(ex);
					throw;
				}
				finally
				{
					connection.Close();
				}
			}
		}

		/// <inheritdoc />
		public void TransferData(
			string sourceConnectionString,
			string targetConnectionString,
			TableConfiguration tableDetails,
			int batchSize,
			Action<long> batchAction)
		{
			this.batchAction = batchAction;
			using (SqlConnection sourceConnection = new SqlConnection(sourceConnectionString))
			{
				string selectQuery = string.Empty;
				if (tableDetails.DefaultLoadType == LoadType.FullLoad)
				{
					selectQuery = "SELECT * FROM " + tableDetails.Name + " (NOLOCK) ";
				}
				else
				{
					selectQuery = "SELECT * FROM " + tableDetails.Name + " (NOLOCK) WHERE " + tableDetails.PartialWhereQuery;
				}


				SqlCommand myCommand = new SqlCommand(selectQuery, sourceConnection);
				if (sourceConnection.State != ConnectionState.Open)
				{
					sourceConnection.Open();
				}

				using (SqlDataReader reader = myCommand.ExecuteReader())
				{
					try
					{

						// open the destination data
						using (SqlConnection destinationConnection = new SqlConnection(targetConnectionString))
						{
							// open the connection
							destinationConnection.Open();

							using (SqlBulkCopy bulkCopy = new SqlBulkCopy(destinationConnection.ConnectionString))
							{
								try
								{
									bulkCopy.BatchSize = batchSize;
									bulkCopy.NotifyAfter = batchSize;
									bulkCopy.SqlRowsCopied += new SqlRowsCopiedEventHandler(BulkCopy_SqlRowsCopied);
									bulkCopy.DestinationTableName = tableDetails.Name;
									bulkCopy.WriteToServer(reader);
								}
								catch (Exception ex)
								{
									ErrorLog.LogException(ex);
									throw;
								}
								finally
								{
									bulkCopy.SqlRowsCopied -= new SqlRowsCopiedEventHandler(BulkCopy_SqlRowsCopied);
								}
							}
						}

					}
					catch (Exception ex)
					{
						ErrorLog.LogException(ex);
						throw;
					}
					finally
					{
						reader.Close();
					}
				}
			}
		}

		/// <summary>
		/// The BulkCopy_SqlRowsCopied
		/// </summary>
		/// <param name="sender">The sender<see cref="object"/></param>
		/// <param name="e">The e<see cref="SqlRowsCopiedEventArgs"/></param>
		private void BulkCopy_SqlRowsCopied(object sender, SqlRowsCopiedEventArgs e)
		{
			this.batchAction?.Invoke(e.RowsCopied);
		}
	}
}
