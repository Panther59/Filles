﻿// <copyright file="Screens.cs" company="Ayvan">
// Copyright (c) 2019 All Rights Reserved
// </copyright>
// <author>UTKARSHLAPTOP\Utkarsh</author>
// <date>2019-08-18</date>

namespace DataMigrator.Common
{
	/// <summary>
	/// Defines the Screens
	/// </summary>
	public enum Screens
	{
		/// <summary>
		/// Defines the Applications
		/// </summary>
		Applications,
		/// <summary>
		/// Defines the Databases
		/// </summary>
		Databases,
		/// <summary>
		/// Defines the Home
		/// </summary>
		Home,
		/// <summary>
		/// Defines the Main
		/// </summary>
		Main,
		/// <summary>
		/// Defines the Tables
		/// </summary>
		Tables,
		/// <summary>
		/// Defines the Settings
		/// </summary>
		Settings
	}
}
