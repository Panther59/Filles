﻿// <copyright file="MainWindow.xaml.cs" company="Ayvan">
// Copyright (c) 2019 All Rights Reserved
// </copyright>
// <author>UTKARSHLAPTOP\Utkarsh</author>
// <date>2019-08-18</date>

namespace DataMigrator
{
	using System.Windows;
	using System.Windows.Controls;
	using DataMigrator.Common;
	using DataMigrator.Contracts;
	using Unity;

	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		/// <summary>
		/// Initializes a new instance of the <see cref="MainWindow"/> class.
		/// </summary>
		/// <param name="resolver">The resolver<see cref="IResolver"/></param>
		public MainWindow()
		{
			InitializeComponent();
			this.Loaded += this.MainWindow_Loaded;
		}

		/// <summary>
		/// The MainWindow_Loaded
		/// </summary>
		/// <param name="sender">The sender<see cref="object"/></param>
		/// <param name="e">The e<see cref="RoutedEventArgs"/></param>
		private void MainWindow_Loaded(object sender, RoutedEventArgs e)
		{
			this.container.Content = UnityConfig.Container.Resolve<UserControl>(Screens.Main.ToString());
		}
	}
}
