﻿// <copyright file="HomeViewModel.cs" company="Ayvan">
// Copyright (c) 2019 All Rights Reserved
// </copyright>
// <author>UTKARSHLAPTOP\Utkarsh</author>
// <date>2019-08-18</date>

namespace DataMigrator.ViewModels
{
	using System;
	using System.Collections.Generic;
	using System.Collections.ObjectModel;
	using System.Data;
	using System.Linq;
	using System.Threading.Tasks;
	using Ayvan.MVVMBase.Entities;
	using DataMigrator.Contracts;
	using DataMigrator.Models;
	using MaterialDesignThemes.Wpf;

	/// <summary>
	/// Defines the <see cref="HomeViewModel" />
	/// </summary>
	public class HomeViewModel : BaseViewModel
	{
		/// <summary>
		/// Defines the appDataHelper
		/// </summary>
		private readonly IAppDataHelper appDataHelper;

		/// <summary>
		/// Defines the sqlServerHelper
		/// </summary>
		private readonly ISqlServerHelper sqlServerHelper;

		/// <summary>
		/// The addToSelectedTableCommand field
		/// </summary>
		private RelayCommand addToSelectedTableCommand;

		/// <summary>
		/// Defines the allDatabases
		/// </summary>
		private List<DatabaseViewModel> allDatabases;

		/// <summary>
		/// The applications field
		/// </summary>
		private List<AppTablesConfiguration> applications;

		/// <summary>
		/// The applicationSelectedCommand field
		/// </summary>
		private RelayCommand applicationSelectedCommand;

		/// <summary>
		/// The logMessage field
		/// </summary>
		private string logMessage;

		/// <summary>
		/// The masterTables field
		/// </summary>
		private ObservableCollection<TableConfiguration> masterTables;

		/// <summary>
		/// Defines the maxInsertRowCount
		/// </summary>
		private int maxInsertRowCount = 10000;
		private int maxDeleteRowCount;

		/// <summary>
		/// The messageQueue field
		/// </summary>
		private SnackbarMessageQueue messageQueue = new SnackbarMessageQueue();

		/// <summary>
		/// The removeFromSelectedTableCommand field
		/// </summary>
		private RelayCommand removeFromSelectedTableCommand;

		/// <summary>
		/// The selectedApplication field
		/// </summary>
		private AppTablesConfiguration selectedApplication;

		/// <summary>
		/// The selectedFromFinalList field
		/// </summary>
		private TableConfiguration selectedFromFinalList;

		/// <summary>
		/// The selectedMasterTable field
		/// </summary>
		private TableConfiguration selectedMasterTable;

		/// <summary>
		/// The selectedTables field
		/// </summary>
		private ObservableCollection<TableConfiguration> selectedTables;

		/// <summary>
		/// The sourceDatabase field
		/// </summary>
		private DatabaseViewModel sourceDatabase;

		/// <summary>
		/// The sourceDatabases field
		/// </summary>
		private ObservableCollection<DatabaseViewModel> sourceDatabases;

		/// <summary>
		/// The targetDatabase field
		/// </summary>
		private DatabaseViewModel targetDatabase;

		/// <summary>
		/// The targetDatabases field
		/// </summary>
		private ObservableCollection<DatabaseViewModel> targetDatabases;

		/// <summary>
		/// The transferDataCommand field
		/// </summary>
		private RelayCommand transferDataCommand;

		/// <summary>
		/// The transferInProgress field
		/// </summary>
		private bool transferInProgress;

		/// <summary>
		/// Initializes a new instance of the <see cref="HomeViewModel"/> class.
		/// </summary>
		/// <param name="appDataHelper">The appDataHelper<see cref="IAppDataHelper"/></param>
		/// <param name="sqlServerHelper">The sqlServerHelper<see cref="ISqlServerHelper"/></param>
		public HomeViewModel(IAppDataHelper appDataHelper, ISqlServerHelper sqlServerHelper)
		{
			this.appDataHelper = appDataHelper;
			this.sqlServerHelper = sqlServerHelper;
			this.Initialize();
		}

		/// <summary>
		/// Gets the AddToSelectedTableCommand
		/// </summary>
		public RelayCommand AddToSelectedTableCommand
		{
			get
			{
				if (this.addToSelectedTableCommand == null)
				{
					this.addToSelectedTableCommand = new RelayCommand(command => this.ExecuteAddToSelectedTable(), can => this.CanAddToSelectedTableExecute());
				}

				return this.addToSelectedTableCommand;
			}
		}

		/// <summary>
		/// Gets or sets the Applications
		/// </summary>
		public List<AppTablesConfiguration> Applications
		{
			get
			{
				return this.applications;
			}

			set
			{
				this.applications = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets the ApplicationSelectedCommand
		/// </summary>
		public RelayCommand ApplicationSelectedCommand
		{
			get
			{
				if (this.applicationSelectedCommand == null)
				{
					this.applicationSelectedCommand = new RelayCommand(command => this.ExecuteApplicationSelected());
				}

				return this.applicationSelectedCommand;
			}
		}

		/// <summary>
		/// Gets or sets the LogMessage
		/// </summary>
		public string LogMessage
		{
			get
			{
				return this.logMessage;
			}

			set
			{
				this.logMessage = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets or sets the MasterTables
		/// </summary>
		public ObservableCollection<TableConfiguration> MasterTables
		{
			get
			{
				return this.masterTables;
			}

			set
			{
				this.masterTables = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets or sets the MessageQueue
		/// </summary>
		public SnackbarMessageQueue MessageQueue
		{
			get
			{
				return this.messageQueue;
			}

			set
			{
				this.messageQueue = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets the RemoveFromSelectedTableCommand
		/// </summary>
		public RelayCommand RemoveFromSelectedTableCommand
		{
			get
			{
				if (this.removeFromSelectedTableCommand == null)
				{
					this.removeFromSelectedTableCommand = new RelayCommand(command => this.ExecuteRemoveFromSelectedTable(), can => this.CanRemoveFromSelectedTableExecute());
				}

				return this.removeFromSelectedTableCommand;
			}
		}

		/// <summary>
		/// Gets or sets the SelectedApplication
		/// </summary>
		public AppTablesConfiguration SelectedApplication
		{
			get
			{
				return this.selectedApplication;
			}

			set
			{
				this.selectedApplication = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets or sets the SelectedFromFinalList
		/// </summary>
		public TableConfiguration SelectedFromFinalList
		{
			get
			{
				return this.selectedFromFinalList;
			}

			set
			{
				this.selectedFromFinalList = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets or sets the SelectedMasterTable
		/// </summary>
		public TableConfiguration SelectedMasterTable
		{
			get
			{
				return this.selectedMasterTable;
			}

			set
			{
				this.selectedMasterTable = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets or sets the SelectedTables
		/// </summary>
		public ObservableCollection<TableConfiguration> SelectedTables
		{
			get
			{
				return this.selectedTables;
			}

			set
			{
				this.selectedTables = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets or sets the SourceDatabase
		/// </summary>
		public DatabaseViewModel SourceDatabase
		{
			get
			{
				return this.sourceDatabase;
			}

			set
			{
				this.sourceDatabase = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets or sets the SourceDatabases
		/// </summary>
		public ObservableCollection<DatabaseViewModel> SourceDatabases
		{
			get
			{
				return this.sourceDatabases;
			}

			set
			{
				this.sourceDatabases = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets or sets the TargetDatabase
		/// </summary>
		public DatabaseViewModel TargetDatabase
		{
			get
			{
				return this.targetDatabase;
			}

			set
			{
				this.targetDatabase = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets or sets the TargetDatabases
		/// </summary>
		public ObservableCollection<DatabaseViewModel> TargetDatabases
		{
			get
			{
				return this.targetDatabases;
			}

			set
			{
				this.targetDatabases = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets the TransferDataCommand
		/// </summary>
		public RelayCommand TransferDataCommand
		{
			get
			{
				if (this.transferDataCommand == null)
				{
					this.transferDataCommand = new RelayCommand(command => this.ExecuteTransferData(), can => this.CanTransferDataExecute());
				}

				return this.transferDataCommand;
			}
		}

		/// <summary>
		/// Gets or sets a value indicating whether TransferInProgress
		/// </summary>
		public bool TransferInProgress
		{
			get
			{
				return this.transferInProgress;
			}

			set
			{
				this.transferInProgress = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// The ViewOpened
		/// </summary>
		public override void ViewOpened()
		{
			this.Initialize();
		}

		/// <summary>
		/// Determines whether AddToSelectedTable can be executed or not
		/// </summary>
		/// <returns>True if can execute or false</returns>
		private bool CanAddToSelectedTableExecute()
		{
			return this.SelectedMasterTable != null && !this.TransferInProgress;
		}

		/// <summary>
		/// Determines whether RemoveFromSelectedTable can be executed or not
		/// </summary>
		/// <returns>True if can execute or false</returns>
		private bool CanRemoveFromSelectedTableExecute()
		{
			return this.SelectedFromFinalList != null && !this.TransferInProgress;
		}

		/// <summary>
		/// Determines whether TransferData can be executed or not
		/// </summary>
		/// <returns>True if can execute or false</returns>
		private bool CanTransferDataExecute()
		{
			return this.SelectedApplication != null &&
				this.SelectedTables != null &&
				this.SelectedTables.Count > 0 &&
				this.SourceDatabase != null &&
				this.TargetDatabase != null &&
				this.TransferInProgress == false;
		}

		/// <summary>
		/// Executes AddToSelectedTable
		/// </summary>
		private void ExecuteAddToSelectedTable()
		{
			var itemToMove = this.SelectedMasterTable;
			var index = this.MasterTables.IndexOf(itemToMove);
			this.MasterTables.Remove(itemToMove);
			if (index < this.MasterTables.Count)
			{
				this.SelectedMasterTable = this.MasterTables[index];
			}
			else if (this.MasterTables.Count > 0)
			{
				this.SelectedMasterTable = this.MasterTables[this.MasterTables.Count - 1];
			}

			if (this.SelectedTables == null)
			{
				this.SelectedTables = new ObservableCollection<TableConfiguration>();
			}

			this.SelectedTables.Add(itemToMove);
			this.SelectedFromFinalList = itemToMove;
		}

		/// <summary>
		/// Executes ApplicationSelected
		/// </summary>
		private void ExecuteApplicationSelected()
		{
			if (this.SelectedApplication != null)
			{
				var dbs = this.allDatabases.Where(x => x.Application.Name == this.SelectedApplication.Application);

				this.SourceDatabases = new ObservableCollection<DatabaseViewModel>(dbs);
				this.TargetDatabases = new ObservableCollection<DatabaseViewModel>(dbs.Where(x => x.Category != DatabaseCategoryType.PROD));

				this.SourceDatabase = null;
				this.TargetDatabase = null;

				this.MasterTables = new ObservableCollection<TableConfiguration>(this.SelectedApplication.Tables);
			}
			else
			{
				this.SourceDatabases = null;
				this.TargetDatabases = null;

				this.SourceDatabase = null;
				this.TargetDatabase = null;

				this.MasterTables = null;
			}
		}

		/// <summary>
		/// Executes RemoveFromSelectedTable
		/// </summary>
		private void ExecuteRemoveFromSelectedTable()
		{
			var itemToMove = this.SelectedFromFinalList;
			var index = this.SelectedTables.IndexOf(itemToMove);
			this.SelectedTables.Remove(itemToMove);
			if (index < this.SelectedTables.Count)
			{
				this.SelectedFromFinalList = this.SelectedTables[index];
			}
			else if (this.SelectedTables.Count > 0)
			{
				this.SelectedFromFinalList = this.SelectedTables[this.SelectedTables.Count - 1];
			}

			if (this.MasterTables == null)
			{
				this.MasterTables = new ObservableCollection<TableConfiguration>();
			}

			this.MasterTables.Add(itemToMove);
			this.SelectedMasterTable = itemToMove;
		}

		/// <summary>
		/// Executes TransferData
		/// </summary>
		private void ExecuteTransferData()
		{
			this.LogMessage = string.Empty;
			this.TransferInProgress = true;
			Task.Run(() =>
			{
				try
				{
					this.WriteLog("Testing for source connection...");
					this.sqlServerHelper.TestConnection(this.SourceDatabase.ConnectionString);
					this.WriteLog("Source connection successfully...");
				}
				catch (Exception ex)
				{
					this.LogException(ex);
					this.WriteLog("Source connection failed...Aborting");
					return;
				}

				try
				{
					this.WriteLog("Testing for target connection...");
					this.sqlServerHelper.TestConnection(this.TargetDatabase.ConnectionString);
					this.WriteLog("Target connection successfully...");
				}
				catch (Exception ex)
				{
					this.LogException(ex);
					this.WriteLog("Target connection failed...Aborting");
					return;
				}

				bool hasError = false;
				foreach (var table in this.selectedTables)
				{
					try
					{
						DateTime startTime = DateTime.Now;
						this.WriteLog(table.Name + " - Transfer started");
						this.WriteLog(table.Name + " - Getting data from source");
						var recordCount = this.sqlServerHelper.GetTableDataCount(this.SourceDatabase.ConnectionString, table);
						this.WriteLog(table.Name + " - " + recordCount + " records will be transferred");
						if (table.TruncateTarget)
						{
							this.WriteLog(table.Name + " - Deleting records in target");
							this.sqlServerHelper.ClearTargetData(this.TargetDatabase.ConnectionString, table, this.maxDeleteRowCount, (x) =>
							 {
								 this.WriteLog(table.Name + " - Deleted " + x + " records in target");
							 });
						}
						this.WriteLog(table.Name + " - Adding data in target");
						this.sqlServerHelper.TransferData(this.SourceDatabase.ConnectionString, this.TargetDatabase.ConnectionString, table, this.maxInsertRowCount, (x) =>
						{
							this.WriteLog(table.Name + " - Transferred " + x + " records in target");
						});
						this.WriteLog(table.Name + " - " + recordCount + " records transferred successfully in " + (DateTime.Now - startTime).TotalSeconds.ToString("0.00") + " seconds");
					}
					catch (Exception ex)
					{
						hasError = true;
						this.LogException(ex);
						this.WriteLog(table.Name + " - Error occured while transferring data (" + ex.Message + ")");
					}
				}

				if (hasError)
				{
					this.MessageQueue.Enqueue("Transfer is completed with some errors");
				}
				else
				{
					this.MessageQueue.Enqueue("Transfer is completed successfully");
				}

				this.TransferInProgress = false;
				this.RefreshUI();
			});
		}

		/// <summary>
		/// The Initialize
		/// </summary>
		private void Initialize()
		{
			this.maxInsertRowCount = this.appDataHelper.Settings.MaxInsertRecordCount;
			this.maxDeleteRowCount = this.appDataHelper.Settings.MaxDeleteRecordCount;

			this.Applications = this.appDataHelper.AppTablesConfigurations;
			this.SelectedApplication = null;
			this.LogMessage = string.Empty;
			this.allDatabases = this.appDataHelper.Databases;
		}

		/// <summary>
		/// The WriteLog
		/// </summary>
		/// <param name="message">The message<see cref="string"/></param>
		private void WriteLog(string message)
		{
			this.LogMessage += (System.Environment.NewLine + "[" + DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss") + "] " + message);
		}
	}
}
