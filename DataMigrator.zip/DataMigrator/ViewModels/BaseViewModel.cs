﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace DataMigrator.ViewModels
{
	public abstract class BaseViewModel : Ayvan.MVVMBase.Entities.BaseViewModel
	{
		public virtual void ViewOpened()
		{
		}

		public void RefreshUI()
		{
			Application.Current.Dispatcher.Invoke(() =>
			{
				CommandManager.InvalidateRequerySuggested();
			});
		}
	}
}
