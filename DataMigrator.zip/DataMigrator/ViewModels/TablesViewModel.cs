﻿// <copyright file="TablesViewModel.cs" company="Ayvan">
// Copyright (c) 2019 All Rights Reserved
// </copyright>
// <author>UTKARSHLAPTOP\Utkarsh</author>
// <date>2019-08-18</date>

namespace DataMigrator.ViewModels
{
	using System;
	using System.Collections.Generic;
	using System.Collections.ObjectModel;
	using System.Linq;
	using System.Threading.Tasks;
	using Ayvan.MVVMBase.Entities;
	using DataMigrator.Contracts;
	using DataMigrator.Models;

	/// <summary>
	/// Defines the <see cref="TablesViewModel" />
	/// </summary>
	public class TablesViewModel : BaseViewModel
	{
		/// <summary>
		/// Defines the appDataHelper
		/// </summary>
		private readonly IAppDataHelper appDataHelper;

		/// <summary>
		/// Defines the resolver
		/// </summary>
		private readonly IResolver resolver;

		/// <summary>
		/// Defines the sqlServerHelper
		/// </summary>
		private readonly ISqlServerHelper sqlServerHelper;

		/// <summary>
		/// The addBulkTablesCommand field
		/// </summary>
		private RelayCommand addBulkTablesCommand;

		/// <summary>
		/// The addNewAppTableConfigCommand field
		/// </summary>
		private RelayCommand addNewAppTableConfigCommand;

		/// <summary>
		/// The addSelectedTableCommand field
		/// </summary>
		private RelayCommand addSelectedTableCommand;

		/// <summary>
		/// Defines the allDatabases
		/// </summary>
		private List<DatabaseViewModel> allDatabases;

		/// <summary>
		/// The applications field
		/// </summary>
		private List<ApplicationViewModel> applications;

		/// <summary>
		/// The applicationSelectedCommand field
		/// </summary>
		private RelayCommand applicationSelectedCommand;

		/// <summary>
		/// The applyBulkTablesCommand field
		/// </summary>
		private RelayCommand applyBulkTablesCommand;

		/// <summary>
		/// The appTableConfigs field
		/// </summary>
		private ObservableCollection<AppTablesConfiguration> appTableConfigs;

		/// <summary>
		/// The bulkTableData field
		/// </summary>
		private string bulkTableData;

		/// <summary>
		/// The cancelBulkTablesCommand field
		/// </summary>
		private RelayCommand cancelBulkTablesCommand;

		/// <summary>
		/// The cancelEditAppTablesCommand field
		/// </summary>
		private RelayCommand cancelEditAppTablesCommand;

		/// <summary>
		/// The databases field
		/// </summary>
		private ObservableCollection<DatabaseViewModel> databases;

		/// <summary>
		/// The databaseSelectedCommand field
		/// </summary>
		private RelayCommand databaseSelectedCommand;

		/// <summary>
		/// The dbTables field
		/// </summary>
		private ObservableCollection<string> dbTables;

		/// <summary>
		/// The deleteAppTableCommand field
		/// </summary>
		private RelayCommand<AppTablesConfiguration> deleteAppTableCommand;

		/// <summary>
		/// The deleteTableCommand field
		/// </summary>
		private RelayCommand<TableViewModel> deleteTableCommand;

		/// <summary>
		/// The editAppTablesCommand field
		/// </summary>
		private RelayCommand<AppTablesConfiguration> editAppTablesCommand;

		/// <summary>
		/// Defines the editExisting
		/// </summary>
		private bool editExisting;

		/// <summary>
		/// Defines the editIndex
		/// </summary>
		private int editIndex;

		/// <summary>
		/// The isEditMode field
		/// </summary>
		private bool isEditMode;

		/// <summary>
		/// The saveNewAppTableConfigCommand field
		/// </summary>
		private RelayCommand saveNewAppTableConfigCommand;

		/// <summary>
		/// The selectedApplication field
		/// </summary>
		private ApplicationViewModel selectedApplication;

		/// <summary>
		/// The selectedDatabase field
		/// </summary>
		private DatabaseViewModel selectedDatabase;

		/// <summary>
		/// The selectedTable field
		/// </summary>
		private string selectedTable;

		/// <summary>
		/// The showBulkSection field
		/// </summary>
		private bool showBulkSection;

		/// <summary>
		/// The tables field
		/// </summary>
		private ObservableCollection<TableViewModel> tables;

		/// <summary>
		/// Initializes a new instance of the <see cref="TablesViewModel"/> class.
		/// </summary>
		/// <param name="appDataHelper">The appDataHelper<see cref="IAppDataHelper"/></param>
		/// <param name="sqlServerHelper">The sqlServerHelper<see cref="ISqlServerHelper"/></param>
		/// <param name="resolver">The resolver<see cref="IResolver"/></param>
		public TablesViewModel(IAppDataHelper appDataHelper, ISqlServerHelper sqlServerHelper, IResolver resolver)
		{
			this.appDataHelper = appDataHelper;
			this.sqlServerHelper = sqlServerHelper;
			this.resolver = resolver;

			this.Initialize();
		}

		/// <summary>
		/// Gets the AddBulkTablesCommand
		/// </summary>
		public RelayCommand AddBulkTablesCommand
		{
			get
			{
				if (this.addBulkTablesCommand == null)
				{
					this.addBulkTablesCommand = new RelayCommand(command => this.ExecuteAddBulkTables());
				}

				return this.addBulkTablesCommand;
			}
		}

		/// <summary>
		/// Gets the AddNewAppTableConfigCommand
		/// </summary>
		public RelayCommand AddNewAppTableConfigCommand
		{
			get
			{
				if (this.addNewAppTableConfigCommand == null)
				{
					this.addNewAppTableConfigCommand = new RelayCommand(command => this.ExecuteAddNewAppTableConfig());
				}

				return this.addNewAppTableConfigCommand;
			}
		}

		/// <summary>
		/// Gets the AddSelectedTableCommand
		/// </summary>
		public RelayCommand AddSelectedTableCommand
		{
			get
			{
				if (this.addSelectedTableCommand == null)
				{
					this.addSelectedTableCommand = new RelayCommand(command => this.ExecuteAddSelectedTable(), can => this.CanAddSelectedTableExecute());
				}

				return this.addSelectedTableCommand;
			}
		}

		/// <summary>
		/// Gets or sets the Applications
		/// </summary>
		public List<ApplicationViewModel> Applications
		{
			get
			{
				return this.applications;
			}

			set
			{
				this.applications = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets the ApplicationSelectedCommand
		/// </summary>
		public RelayCommand ApplicationSelectedCommand
		{
			get
			{
				if (this.applicationSelectedCommand == null)
				{
					this.applicationSelectedCommand = new RelayCommand(command => this.ExecuteApplicationSelected());
				}

				return this.applicationSelectedCommand;
			}
		}

		/// <summary>
		/// Gets the ApplyBulkTablesCommand
		/// </summary>
		public RelayCommand ApplyBulkTablesCommand
		{
			get
			{
				if (this.applyBulkTablesCommand == null)
				{
					this.applyBulkTablesCommand = new RelayCommand(command => this.ExecuteApplyBulkTables(), can => this.CanApplyBulkTablesExecute());
				}

				return this.applyBulkTablesCommand;
			}
		}

		/// <summary>
		/// Gets or sets the AppTableConfigs
		/// </summary>
		public ObservableCollection<AppTablesConfiguration> AppTableConfigs
		{
			get
			{
				return this.appTableConfigs;
			}

			set
			{
				this.appTableConfigs = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets or sets the BulkTableData
		/// </summary>
		public string BulkTableData
		{
			get
			{
				return this.bulkTableData;
			}

			set
			{
				this.bulkTableData = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets the CancelBulkTablesCommand
		/// </summary>
		public RelayCommand CancelBulkTablesCommand
		{
			get
			{
				if (this.cancelBulkTablesCommand == null)
				{
					this.cancelBulkTablesCommand = new RelayCommand(command => this.ExecuteCancelBulkTables());
				}

				return this.cancelBulkTablesCommand;
			}
		}

		/// <summary>
		/// Gets the CancelEditAppTablesCommand
		/// </summary>
		public RelayCommand CancelEditAppTablesCommand
		{
			get
			{
				if (this.cancelEditAppTablesCommand == null)
				{
					this.cancelEditAppTablesCommand = new RelayCommand(command => this.ExecuteCancelEditAppTables());
				}

				return this.cancelEditAppTablesCommand;
			}
		}

		/// <summary>
		/// Gets or sets the Databases
		/// </summary>
		public ObservableCollection<DatabaseViewModel> Databases
		{
			get
			{
				return this.databases;
			}

			set
			{
				this.databases = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets the DatabaseSelectedCommand
		/// </summary>
		public RelayCommand DatabaseSelectedCommand
		{
			get
			{
				if (this.databaseSelectedCommand == null)
				{
					this.databaseSelectedCommand = new RelayCommand(command => this.ExecuteDatabaseSelected());
				}

				return this.databaseSelectedCommand;
			}
		}

		/// <summary>
		/// Gets or sets the DBTables
		/// </summary>
		public ObservableCollection<string> DBTables
		{
			get
			{
				return this.dbTables;
			}

			set
			{
				this.dbTables = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets the DeleteAppTableCommand
		/// </summary>
		public RelayCommand<AppTablesConfiguration> DeleteAppTableCommand
		{
			get
			{
				if (this.deleteAppTableCommand == null)
				{
					this.deleteAppTableCommand = new RelayCommand<AppTablesConfiguration>(command => this.ExecuteDeleteAppTable(command), can => this.CanDeleteAppTableExecute());
				}

				return this.deleteAppTableCommand;
			}
		}

		/// <summary>
		/// Gets the DeleteTableCommand
		/// </summary>
		public RelayCommand<TableViewModel> DeleteTableCommand
		{
			get
			{
				if (this.deleteTableCommand == null)
				{
					this.deleteTableCommand = new RelayCommand<TableViewModel>(command => this.ExecuteDeleteTable(command));
				}

				return this.deleteTableCommand;
			}
		}

		/// <summary>
		/// Gets the EditAppTablesCommand
		/// </summary>
		public RelayCommand<AppTablesConfiguration> EditAppTablesCommand
		{
			get
			{
				if (this.editAppTablesCommand == null)
				{
					this.editAppTablesCommand = new RelayCommand<AppTablesConfiguration>(command => this.ExecuteEditAppTables(command), can => this.CanEditAppTablesExecute());
				}

				return this.editAppTablesCommand;
			}
		}

		/// <summary>
		/// Gets or sets a value indicating whether IsEditMode
		/// </summary>
		public bool IsEditMode
		{
			get
			{
				return this.isEditMode;
			}

			set
			{
				this.isEditMode = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets the SaveNewAppTableConfigCommand
		/// </summary>
		public RelayCommand SaveNewAppTableConfigCommand
		{
			get
			{
				if (this.saveNewAppTableConfigCommand == null)
				{
					this.saveNewAppTableConfigCommand = new RelayCommand(command => this.ExecuteSaveNewAppTableConfig(), can => this.CanSaveNewAppTableConfigExecute());
				}

				return this.saveNewAppTableConfigCommand;
			}
		}

		/// <summary>
		/// Gets or sets the SelectedApplication
		/// </summary>
		public ApplicationViewModel SelectedApplication
		{
			get
			{
				return this.selectedApplication;
			}

			set
			{
				this.selectedApplication = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets or sets the SelectedDatabase
		/// </summary>
		public DatabaseViewModel SelectedDatabase
		{
			get
			{
				return this.selectedDatabase;
			}

			set
			{
				this.selectedDatabase = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets or sets the SelectedTable
		/// </summary>
		public string SelectedTable
		{
			get
			{
				return this.selectedTable;
			}

			set
			{
				this.selectedTable = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets or sets a value indicating whether ShowBulkSection
		/// </summary>
		public bool ShowBulkSection
		{
			get
			{
				return this.showBulkSection;
			}

			set
			{
				this.showBulkSection = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// Gets or sets the Tables
		/// </summary>
		public ObservableCollection<TableViewModel> Tables
		{
			get
			{
				return this.tables;
			}

			set
			{
				this.tables = value;
				this.RaisePropertyChanged();
			}
		}

		/// <summary>
		/// The ViewOpened
		/// </summary>
		public override void ViewOpened()
		{
			this.Initialize();
		}

		/// <summary>
		/// Determines whether AddSelectedTable can be executed or not
		/// </summary>
		/// <returns>True if can execute or false</returns>
		private bool CanAddSelectedTableExecute()
		{
			return string.IsNullOrEmpty(this.SelectedTable) == false && this.DBTables.Any(x => x == this.SelectedTable);
		}

		/// <summary>
		/// Determines whether ApplyBulkTables can be executed or not
		/// </summary>
		/// <returns>True if can execute or false</returns>
		private bool CanApplyBulkTablesExecute()
		{
			return !string.IsNullOrWhiteSpace(this.BulkTableData);
		}

		/// <summary>
		/// Determines whether DeleteAppTable can be executed or not
		/// </summary>
		/// <returns>True if can execute or false</returns>
		private bool CanDeleteAppTableExecute()
		{
			return !this.IsEditMode;
		}

		/// <summary>
		/// Determines whether EditAppTables can be executed or not
		/// </summary>
		/// <returns>True if can execute or false</returns>
		private bool CanEditAppTablesExecute()
		{
			return !this.IsEditMode;
		}

		/// <summary>
		/// Determines whether SaveNewAppTableConfig can be executed or not
		/// </summary>
		/// <returns>True if can execute or false</returns>
		private bool CanSaveNewAppTableConfigExecute()
		{
			return this.SelectedApplication != null && this.Tables != null && this.Tables.Count > 0;
		}

		/// <summary>
		/// Executes AddBulkTables
		/// </summary>
		private void ExecuteAddBulkTables()
		{
			this.ShowBulkSection = true;
		}

		/// <summary>
		/// Executes AddNewAppTableConfig
		/// </summary>
		private void ExecuteAddNewAppTableConfig()
		{
			this.IsEditMode = true;
			this.editExisting = false;
			this.SelectedApplication = null;
			this.Tables = new ObservableCollection<TableViewModel>();
		}

		/// <summary>
		/// Executes AddSelectedTable
		/// </summary>
		private void ExecuteAddSelectedTable()
		{
			if (this.Tables == null)
			{
				this.Tables = new ObservableCollection<TableViewModel>();
			}

			if (this.Tables.Any(x => x.Name == this.SelectedTable) == false)
			{
				this.Tables.Add(new TableViewModel() { Name = this.SelectedTable, DefaultLoadType = Common.LoadType.FullLoad });
			}
		}

		/// <summary>
		/// Executes ApplicationSelected
		/// </summary>
		private void ExecuteApplicationSelected()
		{
			if (this.SelectedApplication != null)
			{
				var dbs = this.allDatabases.Where(x => x.Application.Name == this.SelectedApplication.Name);
				this.Databases = new ObservableCollection<DatabaseViewModel>(dbs.Where(x => x.Category != DatabaseCategoryType.PROD));

				this.SelectedDatabase = null;
			}
			else
			{
				this.Databases = null;
				this.SelectedDatabase = null;
			}
		}

		/// <summary>
		/// Executes ApplyBulkTables
		/// </summary>
		private void ExecuteApplyBulkTables()
		{
			var tables = this.BulkTableData.Split(Environment.NewLine.ToCharArray())
				.Where(x => string.IsNullOrWhiteSpace(x) == false)
				.Select(x => x.Trim());
			if (tables.Any())
			{
				if (this.Tables == null)
				{
					this.Tables = new ObservableCollection<TableViewModel>();
				}

				tables.ToList().ForEach(x =>
				{
					if (this.Tables.Any(t => t.Name == x) == false)
					{
						var newTable = this.resolver.Resolve<TableViewModel>();
						newTable.Name = x;
						newTable.DefaultLoadType = Common.LoadType.FullLoad;

						this.Tables.Add(newTable);
					}
				});
			}

			this.BulkTableData = string.Empty;
			this.ShowBulkSection = false;
		}

		/// <summary>
		/// Executes CancelBulkTables
		/// </summary>
		private void ExecuteCancelBulkTables()
		{
			this.ShowBulkSection = false;
			this.BulkTableData = string.Empty;
		}

		/// <summary>
		/// Executes CancelEditAppTables
		/// </summary>
		private void ExecuteCancelEditAppTables()
		{
			this.IsEditMode = false;
		}

		/// <summary>
		/// Executes DatabaseSelected
		/// </summary>
		private void ExecuteDatabaseSelected()
		{
			Task.Run(() => 
			{
				List<string> tables = this.sqlServerHelper.GetAllTables(this.SelectedDatabase.ConnectionString);
				this.DBTables = new ObservableCollection<string>(tables);
			});
		}

		/// <summary>
		/// Executes DeleteAppTable
		/// </summary>
		/// <param name="input">The <see cref="AppTablesConfiguration"/></param>
		private void ExecuteDeleteAppTable(AppTablesConfiguration input)
		{
			this.AppTableConfigs.Remove(input);
			this.appDataHelper.AppTablesConfigurations = this.AppTableConfigs.ToList();
		}

		/// <summary>
		/// Executes DeleteTable
		/// </summary>
		/// <param name="input">The <see cref="TableViewModel"/></param>
		private void ExecuteDeleteTable(TableViewModel input)
		{
			this.Tables.Remove(input);
		}

		/// <summary>
		/// Executes EditAppTables
		/// </summary>
		/// <param name="input">The <see cref="AppTablesConfiguration"/></param>
		private void ExecuteEditAppTables(AppTablesConfiguration input)
		{
			this.SelectedApplication = this.Applications.FirstOrDefault(x => x.Name == input.Application);
			this.editIndex = this.AppTableConfigs.IndexOf(input);
			this.editExisting = true;
			if (this.Tables == null)
			{
				this.Tables = new ObservableCollection<TableViewModel>();
			}

			input.Tables.ForEach(x =>
			{
				if (this.Tables.Any(t => t.Name == x.Name) == false)
				{
					var newTable = this.resolver.Resolve<TableViewModel>();
					newTable.Name = x.Name;
					newTable.DefaultLoadType = x.DefaultLoadType;
					newTable.PartialWhereQuery = x.PartialWhereQuery;
					newTable.TruncateTarget = x.TruncateTarget;

					this.Tables.Add(newTable);
				}
			});

			this.IsEditMode = true;
		}

		/// <summary>
		/// Executes SaveNewAppTableConfig
		/// </summary>
		private void ExecuteSaveNewAppTableConfig()
		{
			var saveApp = new AppTablesConfiguration();
			saveApp.Application = SelectedApplication.Name;

			saveApp.Tables = new List<TableConfiguration>();
			this.Tables.ToList().ForEach(x =>
			{
				var newTable = new TableConfiguration();
				newTable.Name = x.Name;
				newTable.DefaultLoadType = x.DefaultLoadType;
				newTable.PartialWhereQuery = x.PartialWhereQuery;
				newTable.TruncateTarget = x.TruncateTarget;

				saveApp.Tables.Add(newTable);
			});

			if (this.editExisting)
			{
				this.AppTableConfigs.RemoveAt(editIndex);
				this.AppTableConfigs.Insert(editIndex, saveApp);
			}
			else
			{
				this.AppTableConfigs.Add(saveApp);
			}

			this.appDataHelper.AppTablesConfigurations = this.AppTableConfigs.ToList();
			this.IsEditMode = false;
			this.editExisting = false;
		}

		/// <summary>
		/// The LoadData
		/// </summary>
		private void Initialize()
		{
			this.Applications = this.appDataHelper.Applications;
			this.allDatabases = this.appDataHelper.Databases;
			this.AppTableConfigs = new ObservableCollection<AppTablesConfiguration>(this.appDataHelper.AppTablesConfigurations ?? new List<AppTablesConfiguration>());
		}
	}
}
