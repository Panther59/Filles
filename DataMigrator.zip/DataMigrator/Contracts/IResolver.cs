﻿// <copyright file="IResolver.cs" company="Ayvan">
// Copyright (c) 2019 All Rights Reserved
// </copyright>
// <author>UTKARSHLAPTOP\Utkarsh</author>
// <date>2019-08-18</date>

namespace DataMigrator.Contracts
{
	/// <summary>
	/// Defines the <see cref="IResolver" />
	/// </summary>
	public interface IResolver
	{
		/// <summary>
		/// The Resolve
		/// </summary>
		/// <typeparam name="T"></typeparam>
		/// <returns>The <see cref="T"/></returns>
		T Resolve<T>();

		/// <summary>
		/// The Resolve
		/// </summary>
		/// <typeparam name="T"></typeparam>
		/// <param name="key">The key<see cref="string"/></param>
		/// <returns>The <see cref="T"/></returns>
		T Resolve<T>(string key);
	}
}
